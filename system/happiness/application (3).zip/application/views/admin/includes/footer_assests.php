   
		<!-- jQuery 3 -->
		<script src="<?php echo base_url('assests/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
		
		<!-- Bootstrap 3.3.7 -->
		<script src="<?php echo base_url('assests/bower_components/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
		<!--script src="../../bower_components/bootstrap/dist/js/bootstrap.min.js"></script-->
		<!-- FastClick -->
		<script src="<?php echo base_url('assests/bower_components/fastclick/lib/fastclick.js'); ?>"></script>
		<!--script src="../../bower_components/fastclick/lib/fastclick.js"></script--->
		<!-- AdminLTE App -->
		<script src="<?php echo base_url('assests/dist/js/adminlte.min.js'); ?>"></script>
		<!--script src="../../dist/js/adminlte.min.js"></script-->
		<!-- AdminLTE for demo purposes -->
		<script src="<?php echo base_url('assests/dist/js/demo.js'); ?>"></script>
		<!--script src="../../dist/js/demo.js"></script-->
		
    <script src="<?php echo base_url('assests/vendor/jquery/jquery.min.js'); ?>"></script>
    <script src="<?php echo base_url('assests/vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url('assests/vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>

    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url('assests/vendor/chart.js/Chart.min.js'); ?>"></script>
    <script src="<?php echo base_url('assests/vendor/datatables/jquery.dataTables.js'); ?>"></script>
    <script src="<?php echo base_url('assests/vendor/datatables/dataTables.bootstrap4.js'); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url('assests/js/sb-admin.min.js'); ?>"></script>
    <script src="<?php echo base_url('assests/js/demo/datatables-demo.js'); ?>"></script>
    <script src="<?php echo base_url('assests/js/demo/chart-area-demo.js'); ?>"></script>