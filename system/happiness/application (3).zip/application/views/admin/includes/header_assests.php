  <!-- Bootstrap core CSS-->
<?php echo link_tag('assests/vendor/bootstrap/css/bootstrap.min.css'); ?>
   <?php //echo link_tag('assests/bower_components/bootstrap/dist/css/bootstrap.min.css'); ?>
<!-- Custom fonts for this template-->
<?php echo link_tag('assests/vendor/fontawesome-free/css/all.min.css'); ?>
<!-- Page level plugin CSS-->
<?php //echo link_tag('assests/vendor/datatables/dataTables.bootstrap4.css'); ?>
<!-- Custom styles for this template-->
<?php echo link_tag('assests/css/sb-admin.css'); ?>


 <!-- Bootstrap 3.3.7 -->
	    <!--link rel="stylesheet" href="<?php echo base_url('assests/bower_components/bootstrap/dist/css/bootstrap.min.css'); ?>"-->
	 
 <!-- Font Awesome -->
		<?php //echo link_tag('assests/bower_components/font-awesome/css/font-awesome.min.css'); ?>
		<!--link rel="stylesheet" href="../../bower_components/font-awesome/css/font-awesome.min.css"--->
 <!-- Ionicons -->
	    <?php// echo link_tag('assests/bower_components/Ionicons/css/ionicons.min.css'); ?>
	    <!----link rel="stylesheet" href="../../bower_components/Ionicons/css/ionicons.min.css"--->
 <!-- Theme style -->
		<!--link rel="stylesheet" href="../../dist/css/AdminLTE.min.css"-->
		<?php echo link_tag('assests/dist/css/AdminLTE.min.css'); ?>
 <!-- AdminLTE Skins. Choose a skin from the css/skins
        folder instead of downloading all of them to reduce the load. -->
		<?php echo link_tag('assests/dist/css/skins/_all-skins.min.css'); ?>  
        <!--link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css"-->
 

