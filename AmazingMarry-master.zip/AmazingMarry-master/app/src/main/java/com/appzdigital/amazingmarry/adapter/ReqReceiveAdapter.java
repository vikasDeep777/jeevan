package com.appzdigital.amazingmarry.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.interfaces.ICallback;
import com.appzdigital.amazingmarry.interfaces.ICallback2;
import com.appzdigital.amazingmarry.interfaces.ICallback3;
import com.appzdigital.amazingmarry.model.AllUserListModel;
import com.appzdigital.amazingmarry.network.AppGlobalsUrl;
import com.appzdigital.amazingmarry.utils.AppUtils;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ReqReceiveAdapter extends RecyclerView.Adapter<ReqReceiveAdapter.ViewUserViewHolder> {

    private ICallback iCallback;
    private ICallback2 iCallback2;
    private ICallback3 iCallback3;
    private List<AllUserListModel> userModel;
    private List<AllUserListModel> filterlist;
    private Context context;


    public ReqReceiveAdapter(List userModel, Context context, ICallback iCallback, ICallback2 iCallback2, ICallback3 iCallback3) {
        this.userModel = userModel;
        this.context = context;
        this.iCallback = iCallback;
        this.iCallback2 = iCallback2;
        this.iCallback3 = iCallback3;
        this.filterlist = new ArrayList<AllUserListModel>();
        this.filterlist.addAll(userModel);

    }

    @NonNull
    @Override
    public ReqReceiveAdapter.ViewUserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate the layout file
        View notification_list = LayoutInflater.from(parent.getContext()).inflate(R.layout.req_received_item, parent, false);
        ReqReceiveAdapter.ViewUserViewHolder notificationlist = new ReqReceiveAdapter.ViewUserViewHolder(notification_list);
        AppUtils.setScaleAnimation(notification_list);
        return notificationlist;
    }

    @Override
    public void onBindViewHolder(@NonNull ReqReceiveAdapter.ViewUserViewHolder holder, final int position) {

        String f_name = userModel.get(position).getName();
        String l_name = userModel.get(position).getLast_name();
        String city = userModel.get(position).getCity();
        String country = userModel.get(position).getCountry();
        String dob = userModel.get(position).getDob();
        String image = userModel.get(position).getImage();


        holder.name_tv.setText(f_name + " " + l_name + ", " + AppUtils.getAge(dob));
        holder.city_tv.setText(city + ", " + country);

        if (image.equalsIgnoreCase("") || image.equalsIgnoreCase("null")) {
            holder.profile_iv.setImageResource(R.drawable.image1);
        } else {
            Picasso.get().
                    load(AppGlobalsUrl.image_url + image).
                    into(holder.profile_iv);
        }

        holder.card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iCallback.onItemClick(position);

            }
        });


        holder.accept_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iCallback2.onItemClick(position);

            }
        });
        holder.reject_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iCallback3.onItemClick(position);

            }
        });

    }

    @Override
    public int getItemCount() {
        return userModel.size();
    }

    public class ViewUserViewHolder extends RecyclerView.ViewHolder {
        TextView name_tv, city_tv;
        ImageView profile_iv;
        Button accept_btn, reject_btn;
        CardView card_view;

        public ViewUserViewHolder(View view) {
            super(view);
            profile_iv = view.findViewById(R.id.profile_iv);
            name_tv = view.findViewById(R.id.name_tv);
            city_tv = view.findViewById(R.id.city_tv);
            accept_btn = view.findViewById(R.id.accept_btn);
            reject_btn = view.findViewById(R.id.reject_btn);
            card_view = view.findViewById(R.id.card_view);
        }
    }


    //ToDo Filter Class
    public void filter(CharSequence charText) {
        //charText = charText.toLowerCase(Locale.getDefault());
        userModel.clear();
        if (charText.length() == 0) {
            userModel.addAll(filterlist);
        } else {
            for (AllUserListModel list : filterlist) {
                if (list.getName().toLowerCase(Locale.getDefault()).contains(charText)) {
                    userModel.add(list);
                }
            }
        }
        notifyDataSetChanged();
    }

}



