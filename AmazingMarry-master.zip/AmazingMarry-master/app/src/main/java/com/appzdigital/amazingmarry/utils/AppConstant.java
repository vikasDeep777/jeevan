package com.appzdigital.amazingmarry.utils;

public class AppConstant {

    public static String v_code ="1.0";
    public static String apikey ="fbb36f24d9b3985aa86fa37fd51c29eb";
    public static String deviceType ="Android";
    public static String app_name ="Amazing Marry";
    public static String json_type ="application/json; charset=utf-8";
    public static final int GPS_REQUEST = 1001;
    public static final int LOCATION_REQUEST = 1000;

}
