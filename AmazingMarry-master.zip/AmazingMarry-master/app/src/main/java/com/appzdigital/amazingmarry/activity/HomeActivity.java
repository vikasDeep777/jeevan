package com.appzdigital.amazingmarry.activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.adapter.AllUserListAdapter;
import com.appzdigital.amazingmarry.adapter.SearchUserAdapter;
import com.appzdigital.amazingmarry.fragment.ChatFragment;
import com.appzdigital.amazingmarry.fragment.HomeFragment;
import com.appzdigital.amazingmarry.fragment.NearByMeFragment;
import com.appzdigital.amazingmarry.fragment.RequestFragment;
import com.appzdigital.amazingmarry.fragment.SearchAllUserFragment;
import com.appzdigital.amazingmarry.interfaces.ICallback;
import com.appzdigital.amazingmarry.model.AllUserListModel;
import com.appzdigital.amazingmarry.network.AppGlobalsUrl;
import com.appzdigital.amazingmarry.network.NetworkConnectionCheck;
import com.appzdigital.amazingmarry.network.VolleySingleton;
import com.appzdigital.amazingmarry.utils.AppConstant;
import com.appzdigital.amazingmarry.utils.AppUtils;
import com.appzdigital.amazingmarry.utils.PrefrenceManager;
import com.appzdigital.amazingmarry.utils.SmoothActionBarDrawerToggle;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;
import com.quickblox.core.QBEntityCallback;
import com.quickblox.core.exception.QBResponseException;
import com.quickblox.users.model.QBUser;
import com.squareup.picasso.Picasso;

import androidx.core.view.MenuItemCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import app.quick_chat.ui.activity.DialogsActivity;
import app.quick_chat.utils.SharedPrefsHelper;
import app.quick_chat.utils.chat.ChatHelper;

public class HomeActivity extends AppCompatActivity
        implements SearchView.OnQueryTextListener,NavigationView.OnNavigationItemSelectedListener , HomeFragment.OnFragmentInteractionListener, ChatFragment.OnFragmentInteractionListener, NearByMeFragment.OnFragmentInteractionListener, RequestFragment.OnFragmentInteractionListener {

    private boolean doubleBackToExitPressedOnce = false;
    private DrawerLayout drawer;
    private CoordinatorLayout coordinateLayout;
    private Toolbar toolbar;
    public BottomNavigationView bottomNavigation;
    private PrefrenceManager prefrenceManager;
    private TextView nav_name_tv, nav_email_tv;
    private ImageView profile_iv;
    private NavigationView navigationView;
    private NetworkConnectionCheck networkConnectionCheck;
    public static String search_data;


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.frame_container);

        Fragment fragment = null;

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.btm_home:

                    if (!(currentFragment instanceof HomeFragment)) {
                        FragmentManager fm13 = getSupportFragmentManager();
                        for (int i = 0; i < fm13.getBackStackEntryCount(); ++i) {
                            fm13.popBackStack();
                        }
                        fragment = new HomeFragment();
                        navigationView.setCheckedItem(R.id.nav_home);
                    }

                    break;
                case R.id.btm_inbox:
                    if (!(currentFragment instanceof ChatFragment)) {
                        FragmentManager fm13 = getSupportFragmentManager();
                        for (int i = 0; i < fm13.getBackStackEntryCount(); ++i) {
                            fm13.popBackStack();
                        }
                        fragment = new ChatFragment();
                    }
                    break;
                case R.id.btm_nearby:
                    if (!(currentFragment instanceof NearByMeFragment)) {
                        FragmentManager fm13 = getSupportFragmentManager();
                        for (int i = 0; i < fm13.getBackStackEntryCount(); ++i) {
                            fm13.popBackStack();
                        }
                        fragment = new NearByMeFragment();
                    }
                    break;

                case R.id.btm_request:
                    if (!(currentFragment instanceof RequestFragment)) {
                        FragmentManager fm13 = getSupportFragmentManager();
                        for (int i = 0; i < fm13.getBackStackEntryCount(); ++i) {
                            fm13.popBackStack();
                        }
                        fragment = new RequestFragment();
                    }

                    break;
            }
            return loadFragment(fragment);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        init();
    }

    public void init() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        coordinateLayout = findViewById(R.id.coordinateLayout);
        drawer = findViewById(R.id.drawer_layout);
        bottomNavigation = findViewById(R.id.bottomNavigation);
        bottomNavigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        toggle = new SmoothActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            public void onDrawerClosed(View view) {
                supportInvalidateOptionsMenu();
            }

            public void onDrawerOpened(View drawerView) {
                supportInvalidateOptionsMenu();
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(drawer.getWindowToken(), 0);
                coordinateLayout.setTranslationX(slideOffset * drawerView.getWidth());
                drawer.bringChildToFront(drawerView);
                drawer.requestLayout();
            }
        };
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View view = navigationView.getHeaderView(0);
        prefrenceManager = new PrefrenceManager(this);
        networkConnectionCheck = new NetworkConnectionCheck(this);
        String f_name = prefrenceManager.fetchF_name();
        String l_name = prefrenceManager.fetchL_name();
        String email = prefrenceManager.fetchEmail();
        String profile_pic = prefrenceManager.fetchPhoto();
        nav_name_tv = view.findViewById(R.id.nav_name_tv);
        nav_email_tv = view.findViewById(R.id.nav_email_tv);
        profile_iv = view.findViewById(R.id.profile_iv);
        nav_name_tv.setText(f_name+" "+l_name);
        nav_email_tv.setText(email);

        if (profile_pic.equalsIgnoreCase("")||profile_pic.equalsIgnoreCase("null")){

            profile_iv.setImageResource(R.drawable.image1);
        }else {
            Picasso.get().
                    load(profile_pic).
                    into(profile_iv);
        }

            Fragment frag = new HomeFragment();
            FragmentManager manager = getSupportFragmentManager();
            FragmentTransaction transaction = manager.beginTransaction();
            transaction.replace(R.id.frame_container, frag, "Home Fragment");
            transaction.addToBackStack(null);
            transaction.commit();
            ChatLogin(email);


    }

    @Override
    public void onBackPressed() {
        View view = findViewById(android.R.id.content);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
                drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
                super.onBackPressed();
            } else if (getSupportFragmentManager().getBackStackEntryCount() == 0) {
                if (doubleBackToExitPressedOnce) {
                    super.onBackPressed();
                    return;
                }
                this.doubleBackToExitPressedOnce = true;
                Snackbar.make(view, "Press again to Exit", Snackbar.LENGTH_LONG).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        doubleBackToExitPressedOnce = false;
                    }
                }, 2000);
            } else {
                drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
                super.onBackPressed();
            }
        }
    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
            Fragment frag = new HomeFragment();
            FragmentManager manager = getSupportFragmentManager();
            FragmentTransaction transaction = manager.beginTransaction();
            transaction.replace(R.id.frame_container, frag, "Home Fragment");
            transaction.commit();
            bottomNavigation.setSelectedItemId(R.id.btm_home);

        } else if (id == R.id.nav_update_profile) {

        } else if (id == R.id.nav_help_support) {

        } else if (id == R.id.nav_acc_setting) {

        }else if (id == R.id.nav_privacy_policy) {

        }else if (id == R.id.nav_terms_conditions) {

        }else if (id == R.id.nav_share) {
            appShare(this);
        } else if (id == R.id.nav_logout) {
            logout_alert_dialog();
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.home, menu);

        MenuItem searchItem = menu.findItem(R.id.action_search);

        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setQueryHint("Search People");
        searchView.setOnQueryTextListener(this);
        searchView.setIconified(false);

        MenuItemCompat.setOnActionExpandListener(searchItem, new MenuItemCompat.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                // Do something when collapsed

                FragmentManager fm13 = getSupportFragmentManager();
                for (int i = 0; i < fm13.getBackStackEntryCount(); ++i) {
                    fm13.popBackStack();
                }

                return true;  // Return true to collapse action view

            }

            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {

                return true;
            }
        });

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.action_notification: {
                // Do something
                //DialogsActivity.start(HomeActivity.this);

                return true;
            }

          /*  case R.id.action_search: {
                // Do something
                //DialogsActivity.start(HomeActivity.this);

                return true;
            }*/


        }
        return super.onOptionsItemSelected(item);
    }


    public static void appShare(Context context) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.app_name));
        sendIntent.putExtra(Intent.EXTRA_TEXT, "I Tried This App for Amazing Marry and its cool \n\n http://play.google.com/store/apps/details?id=" + context.getPackageName());
        sendIntent.setType("text/plain");
        context.startActivity(sendIntent);
    }

    private void isUserLogedOut(boolean status) {
        prefrenceManager.isUserLogedOut();
    }

    public void logout_alert_dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.logout_dialog, null);
        Button yes_btn = dialogView.findViewById(R.id.yes_btn);
        Button no_btn = dialogView.findViewById(R.id.no_btn);
        ImageView close_iv = dialogView.findViewById(R.id.close_iv);
        builder.setView(dialogView);
        final AlertDialog dialog = builder.create();
        dialog.getWindow().getAttributes().windowAnimations = R.style.animationdialog;
        close_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                dialog.cancel();
            }
        });
        no_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                dialog.cancel();
            }
        });
        yes_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                isUserLogedOut(true);
                Intent intent = new Intent(HomeActivity.this, IntroActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override
    public void onFragmentInteraction(Uri uri) {
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, fragment).commit();
            return true;
        }
        return false;
    }



    public void ChatLogin(String email) {

        final QBUser user = new QBUser(email, "12345678");
        ChatHelper.getInstance().login(user, new QBEntityCallback<Void>() {
            @Override
            public void onSuccess(Void result, Bundle bundle) {
                SharedPrefsHelper.getInstance().saveQbUser(user);
                Log.d("id==", String.valueOf(user.getId()));
                loginToChat(user, getApplicationContext());
            }

            @Override
            public void onError(QBResponseException e) {
            }
        });
    }

    private void loginToChat(final QBUser user, final Context context) {

        ChatHelper.getInstance().loginToChat(user, new QBEntityCallback<Void>() {
            @Override
            public void onSuccess(Void result, Bundle bundle) {
                //This method is calling to subscribe push notification

            }

            @Override
            public void onError(QBResponseException e) {
                Log.e("Chat login onError(): ", "" + e);

            }
        });
    }

    @Override
    public boolean onQueryTextSubmit(String query) {

        search_data=query;
       // search_user_list_NetworkCall(search_txt);

        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {

        search_data=newText;

        if (newText.equalsIgnoreCase("")){

            Log.d("", "onQueryTextChange: ");
        }else {

            Fragment frag = new SearchAllUserFragment();
            FragmentManager manager = getSupportFragmentManager();
            FragmentTransaction transaction = manager.beginTransaction();
            transaction.replace(R.id.frame_container, frag, "Search Fragment");
            transaction.commit();
        }
        return false;
    }



}
