package com.appzdigital.amazingmarry.network;

public class AppGlobalsUrl {


    private static String BaseUrl = "https://www.amazingmarry.com/index.php/api/";
    public static String image_url = "https://www.amazingmarry.com/assets/uploads/profile_image/";

    /*Post request*/
    public static String AllUserList = BaseUrl + "amazing/all_list_record";
    public static String searchrecord = BaseUrl + "amazing/searchrecord";
    public static String searchrecord_bylatlang = BaseUrl + "amazing/searchrecord_bylatlang";
    public static String connection_list = BaseUrl + "amazing/connection_list";
    public static String user_connection = BaseUrl + "amazing/user_connection";
    public static String connection_recieved = BaseUrl + "amazing/connection_recieved";
    public static String connection_accept_or_reject = BaseUrl + "amazing/connection_accept_or_reject";
    public static String state_list = BaseUrl + "amazing/state_list";


}
