package com.appzdigital.amazingmarry.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.interfaces.ICallback;
import com.appzdigital.amazingmarry.model.AllUserListModel;
import com.appzdigital.amazingmarry.model.PendingListModel;
import com.appzdigital.amazingmarry.network.AppGlobalsUrl;
import com.appzdigital.amazingmarry.utils.AppUtils;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PendingRequestAdapter extends RecyclerView.Adapter<PendingRequestAdapter.ViewUserViewHolder> {

    private ICallback iCallback;
    private List<PendingListModel> userModel;
    private List<PendingListModel> filterlist;
    private Context context;


    public PendingRequestAdapter(List userModel, Context context, ICallback iCallback) {
        this.userModel = userModel;
        this.context = context;
        this.iCallback = iCallback;
        this.filterlist = new ArrayList<PendingListModel>();
        this.filterlist.addAll(userModel);

    }

    @NonNull
    @Override
    public PendingRequestAdapter.ViewUserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate the layout file
        View notification_list = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_item_list, parent, false);
        PendingRequestAdapter.ViewUserViewHolder notificationlist = new PendingRequestAdapter.ViewUserViewHolder(notification_list);
        AppUtils.setScaleAnimation(notification_list);
        return notificationlist;
    }

    @Override
    public void onBindViewHolder(@NonNull PendingRequestAdapter.ViewUserViewHolder holder, final int position) {

        String f_name=userModel.get(position).getName();
        String l_name=userModel.get(position).getLast_name();
        String city=userModel.get(position).getCity();
        String country=userModel.get(position).getCountry();
        String dob=userModel.get(position).getDob();
        String image=userModel.get(position).getImage();
        String connection_status=userModel.get(position).getConnection_info();

        Toast.makeText(context, ""+connection_status, Toast.LENGTH_SHORT).show();

        if (connection_status.equalsIgnoreCase("0")){

            holder.connect_btn.setText("connect");
            holder.connect_btn.setVisibility(View.VISIBLE);


        }else if (connection_status.equalsIgnoreCase("1")){

            holder.connect_btn.setText("Cancel");
            holder.connect_btn.setVisibility(View.VISIBLE);
            holder.connect_btn.setBackgroundResource(R.drawable.btn_background_orange);

        }else if (connection_status.equalsIgnoreCase("2")){

            holder.connect_btn.setText("Accepted");
            holder.connect_btn.setVisibility(View.GONE);


        }else if (connection_status.equalsIgnoreCase("3")){

            holder.connect_btn.setText("Rejected");
            holder.connect_btn.setVisibility(View.GONE);


        }


        holder.name_tv.setText(f_name+" "+l_name+", "+AppUtils.getAge(dob));
        holder.city_tv.setText(city+", "+country);

        if (image.equalsIgnoreCase("")||image.equalsIgnoreCase("null")){
            holder.profile_iv.setImageResource(R.drawable.image1);
        }else {
            Picasso.get().
                    load(AppGlobalsUrl.image_url+image).
                    into(holder.profile_iv);
        }

        holder.card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iCallback.onItemClick(position);

            }
        });

    }

    @Override
    public int getItemCount() {
        return userModel.size();
    }

    public class ViewUserViewHolder extends RecyclerView.ViewHolder {
        TextView name_tv,city_tv;
        ImageView profile_iv;
        Button connect_btn;
        CardView card_view;
        public ViewUserViewHolder(View view) {
            super(view);
            profile_iv = view.findViewById(R.id.profile_iv);
            name_tv = view.findViewById(R.id.name_tv);
            city_tv = view.findViewById(R.id.city_tv);
            connect_btn = view.findViewById(R.id.connect_btn);
            card_view = view.findViewById(R.id.card_view);
        }
    }


    //ToDo Filter Class
    public void filter(CharSequence charText) {
        //charText = charText.toLowerCase(Locale.getDefault());
        userModel.clear();
        if (charText.length() == 0) {
            userModel.addAll(filterlist);
        } else {
            for (PendingListModel list : filterlist) {
                if (list.getName().toLowerCase(Locale.getDefault()).contains(charText)) {
                    userModel.add(list);
                }
            }
        }
        notifyDataSetChanged();
    }

}



