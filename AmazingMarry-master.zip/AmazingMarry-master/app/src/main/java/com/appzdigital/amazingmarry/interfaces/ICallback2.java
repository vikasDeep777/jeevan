package com.appzdigital.amazingmarry.interfaces;

public interface ICallback2 {

    public void onItemClick(int pos);

}

