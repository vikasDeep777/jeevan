package com.appzdigital.amazingmarry.model.UserListModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("mobileNo")
    @Expose
    private String mobileNo;
    @SerializedName("role_id")
    @Expose
    private Object roleId;
    @SerializedName("is_default")
    @Expose
    private String isDefault;
    @SerializedName("app_name")
    @Expose
    private Object appName;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("temp_password")
    @Expose
    private String tempPassword;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("reset_key")
    @Expose
    private Object resetKey;
    @SerializedName("deviceType")
    @Expose
    private String deviceType;
    @SerializedName("deviceID")
    @Expose
    private String deviceID;
    @SerializedName("device_token")
    @Expose
    private String deviceToken;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("last_logged_in")
    @Expose
    private String lastLoggedIn;
    @SerializedName("created_at")
    @Expose
    private String createdAt;
    @SerializedName("modified_at")
    @Expose
    private String modifiedAt;
    @SerializedName("created_by")
    @Expose
    private String createdBy;
    @SerializedName("modified_by")
    @Expose
    private String modifiedBy;
    @SerializedName("activation_key")
    @Expose
    private String activationKey;
    @SerializedName("email_active_status")
    @Expose
    private String emailActiveStatus;
    @SerializedName("notification_status")
    @Expose
    private String notificationStatus;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("phone")
    @Expose
    private Object phone;
    @SerializedName("present_address")
    @Expose
    private Object presentAddress;
    @SerializedName("permanent_address")
    @Expose
    private String permanentAddress;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("state")
    @Expose
    private String state;
    @SerializedName("country")
    @Expose
    private String country;
    @SerializedName("education_category")
    @Expose
    private String educationCategory;
    @SerializedName("qualification")
    @Expose
    private String qualification;
    @SerializedName("gender")
    @Expose
    private String gender;
    @SerializedName("hobbies")
    @Expose
    private String hobbies;
    @SerializedName("fav_actor")
    @Expose
    private String favActor;
    @SerializedName("fav_actress")
    @Expose
    private String favActress;
    @SerializedName("food_type")
    @Expose
    private String foodType;
    @SerializedName("partner_type")
    @Expose
    private String partnerType;
    @SerializedName("mother_tongue")
    @Expose
    private String motherTongue;
    @SerializedName("marital_status")
    @Expose
    private String maritalStatus;
    @SerializedName("occupation_sector")
    @Expose
    private String occupationSector;
    @SerializedName("occupation_type")
    @Expose
    private String occupationType;
    @SerializedName("blood_group")
    @Expose
    private Object bloodGroup;
    @SerializedName("religion")
    @Expose
    private String religion;
    @SerializedName("dob")
    @Expose
    private String dob;
    @SerializedName("joining_date")
    @Expose
    private Object joiningDate;
    @SerializedName("resign_date")
    @Expose
    private Object resignDate;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("caste")
    @Expose
    private String caste;
    @SerializedName("height")
    @Expose
    private String height;
    @SerializedName("height_m1")
    @Expose
    private Object heightM1;
    @SerializedName("height_m2")
    @Expose
    private Object heightM2;
    @SerializedName("profile_for")
    @Expose
    private String profileFor;
    @SerializedName("other_info")
    @Expose
    private Object otherInfo;
    @SerializedName("country_code")
    @Expose
    private Object countryCode;
    @SerializedName("quick_blox_id")
    @Expose
    private String quickBloxId;
    @SerializedName("latitude")
    @Expose
    private String latitude;
    @SerializedName("longitude")
    @Expose
    private String longitude;
    @SerializedName("current_address")
    @Expose
    private Object currentAddress;
    @SerializedName("payment_status")
    @Expose
    private String paymentStatus;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public Object getRoleId() {
        return roleId;
    }

    public void setRoleId(Object roleId) {
        this.roleId = roleId;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    public Object getAppName() {
        return appName;
    }

    public void setAppName(Object appName) {
        this.appName = appName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTempPassword() {
        return tempPassword;
    }

    public void setTempPassword(String tempPassword) {
        this.tempPassword = tempPassword;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Object getResetKey() {
        return resetKey;
    }

    public void setResetKey(Object resetKey) {
        this.resetKey = resetKey;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLastLoggedIn() {
        return lastLoggedIn;
    }

    public void setLastLoggedIn(String lastLoggedIn) {
        this.lastLoggedIn = lastLoggedIn;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getModifiedAt() {
        return modifiedAt;
    }

    public void setModifiedAt(String modifiedAt) {
        this.modifiedAt = modifiedAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getActivationKey() {
        return activationKey;
    }

    public void setActivationKey(String activationKey) {
        this.activationKey = activationKey;
    }

    public String getEmailActiveStatus() {
        return emailActiveStatus;
    }

    public void setEmailActiveStatus(String emailActiveStatus) {
        this.emailActiveStatus = emailActiveStatus;
    }

    public String getNotificationStatus() {
        return notificationStatus;
    }

    public void setNotificationStatus(String notificationStatus) {
        this.notificationStatus = notificationStatus;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Object getPhone() {
        return phone;
    }

    public void setPhone(Object phone) {
        this.phone = phone;
    }

    public Object getPresentAddress() {
        return presentAddress;
    }

    public void setPresentAddress(Object presentAddress) {
        this.presentAddress = presentAddress;
    }

    public String getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getEducationCategory() {
        return educationCategory;
    }

    public void setEducationCategory(String educationCategory) {
        this.educationCategory = educationCategory;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHobbies() {
        return hobbies;
    }

    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }

    public String getFavActor() {
        return favActor;
    }

    public void setFavActor(String favActor) {
        this.favActor = favActor;
    }

    public String getFavActress() {
        return favActress;
    }

    public void setFavActress(String favActress) {
        this.favActress = favActress;
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public String getPartnerType() {
        return partnerType;
    }

    public void setPartnerType(String partnerType) {
        this.partnerType = partnerType;
    }

    public String getMotherTongue() {
        return motherTongue;
    }

    public void setMotherTongue(String motherTongue) {
        this.motherTongue = motherTongue;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getOccupationSector() {
        return occupationSector;
    }

    public void setOccupationSector(String occupationSector) {
        this.occupationSector = occupationSector;
    }

    public String getOccupationType() {
        return occupationType;
    }

    public void setOccupationType(String occupationType) {
        this.occupationType = occupationType;
    }

    public Object getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(Object bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getReligion() {
        return religion;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public Object getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(Object joiningDate) {
        this.joiningDate = joiningDate;
    }

    public Object getResignDate() {
        return resignDate;
    }

    public void setResignDate(Object resignDate) {
        this.resignDate = resignDate;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCaste() {
        return caste;
    }

    public void setCaste(String caste) {
        this.caste = caste;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public Object getHeightM1() {
        return heightM1;
    }

    public void setHeightM1(Object heightM1) {
        this.heightM1 = heightM1;
    }

    public Object getHeightM2() {
        return heightM2;
    }

    public void setHeightM2(Object heightM2) {
        this.heightM2 = heightM2;
    }

    public String getProfileFor() {
        return profileFor;
    }

    public void setProfileFor(String profileFor) {
        this.profileFor = profileFor;
    }

    public Object getOtherInfo() {
        return otherInfo;
    }

    public void setOtherInfo(Object otherInfo) {
        this.otherInfo = otherInfo;
    }

    public Object getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(Object countryCode) {
        this.countryCode = countryCode;
    }

    public String getQuickBloxId() {
        return quickBloxId;
    }

    public void setQuickBloxId(String quickBloxId) {
        this.quickBloxId = quickBloxId;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public Object getCurrentAddress() {
        return currentAddress;
    }

    public void setCurrentAddress(Object currentAddress) {
        this.currentAddress = currentAddress;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

}