package com.appzdigital.amazingmarry.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.loader.content.CursorLoader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.ArrayMap;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.adapter.CityAdapter;
import com.appzdigital.amazingmarry.adapter.CountryAdapter;
import com.appzdigital.amazingmarry.adapter.EducationAdapter;
import com.appzdigital.amazingmarry.adapter.EducationTypeAdapter;
import com.appzdigital.amazingmarry.adapter.HeightAdapter;
import com.appzdigital.amazingmarry.adapter.SpinnerAdapter;
import com.appzdigital.amazingmarry.adapter.StateAdapter;
import com.appzdigital.amazingmarry.databinding.ActivityRegisterBinding;
import com.appzdigital.amazingmarry.interfaces.ICallback;
import com.appzdigital.amazingmarry.model.CityModel.CityModel;
import com.appzdigital.amazingmarry.model.CountryModel.CountryModel;
import com.appzdigital.amazingmarry.model.EducationFieldModel.EducationFieldModel;
import com.appzdigital.amazingmarry.model.EducationModel.EducationModel;
import com.appzdigital.amazingmarry.model.HeightModel.HeightModel;
import com.appzdigital.amazingmarry.model.RegisterModel;
import com.appzdigital.amazingmarry.model.SpinnerModel.SpinnerModel;
import com.appzdigital.amazingmarry.model.StateModel.StateModel;
import com.appzdigital.amazingmarry.network.ApiUtils;
import com.appzdigital.amazingmarry.network.NetworkConnectionCheck;
import com.appzdigital.amazingmarry.network.RestInterfaces;
import com.appzdigital.amazingmarry.utils.AppConstant;
import com.appzdigital.amazingmarry.utils.AppUtils;
import com.appzdigital.amazingmarry.utils.GpsUtils;
import com.appzdigital.amazingmarry.utils.PrefrenceManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.gson.GsonBuilder;
import com.quickblox.core.QBEntityCallback;
import com.quickblox.core.exception.QBResponseException;
import com.quickblox.core.helper.StringifyArrayList;
import com.quickblox.users.QBUsers;
import com.quickblox.users.model.QBUser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import app.quick_chat.utils.SharedPrefsHelper;
import app.quick_chat.utils.chat.ChatHelper;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    private ActivityRegisterBinding registerBinding;

    private String spinner_list_name, f_name, l_name, email, password, mobile_no, gender="", profile_for, dob, country, state, city, hobbies, fav_actor, fav_actress, caste, religion,
            mother_tongue, marital_status, height, food, education, education_field, occupation, occupation_type, partner_type, latitude, longitude, deviceID, current_address, device_token;
    private ProgressDialog progressDialog;
    private NetworkConnectionCheck networkConnectionCheck;
    private PrefrenceManager prefrenceManager;
    private FusedLocationProviderClient mFusedLocationClient;
    private double wayLatitude = 0.0, wayLongitude = 0.0;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;
    private StringBuilder stringBuilder;
    private boolean isContinue = false;
    private boolean isGPS = false;
    private Geocoder geocoder;
    private Uri contentURI;
    private List<Address> addresses;
    double lats, longst;
    private String imagepath,country_id,state_id;
    private int GALLERY = 1, CAMERA = 2;
    private static final String IMAGE_DIRECTORY = "/AmazingMarry";


    private ICallback iCallback;
    RecyclerView recycler_view;
    List<com.appzdigital.amazingmarry.model.SpinnerModel.Response> spinnerModelList = new ArrayList<>();
    List<com.appzdigital.amazingmarry.model.CountryModel.Response> country_list = new ArrayList<>();
    List<com.appzdigital.amazingmarry.model.EducationModel.Response> education_list = new ArrayList<>();
    List<com.appzdigital.amazingmarry.model.EducationFieldModel.Response> education_type_list = new ArrayList<>();
    List<com.appzdigital.amazingmarry.model.HeightModel.Response> height_list = new ArrayList<>();
    List<com.appzdigital.amazingmarry.model.StateModel.Response> state_list = new ArrayList<>();
    List<com.appzdigital.amazingmarry.model.CityModel.Response> city_list = new ArrayList<>();
    SpinnerAdapter spinnerAdapter;
    CountryAdapter countryAdapter;
    StateAdapter stateAdapter;
    CityAdapter cityAdapter;
    EducationAdapter educationAdapter;
    EducationTypeAdapter educationTypeAdapter;
    HeightAdapter heightAdapter;
    TextView tvNoData;
    ProgressBar myprogressbar;
    EditText search_edtText;


    private int day, month, year;
    private Calendar mcurrentDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerBinding = DataBindingUtil.setContentView(this, R.layout.activity_register);

        init();

    }

    public void init() {

        registerBinding.submitBtn.setAlpha(0.5f);
        registerBinding.submitBtn.setClickable(false);
        registerBinding.submitBtn.setEnabled(false);

        registerBinding.submitBtn.setOnClickListener(this);
        registerBinding.termsConditionChkBox.setOnClickListener(this);
        registerBinding.termsTv.setOnClickListener(this);
        registerBinding.profileIv.setOnClickListener(this);
        registerBinding.profileForEt.setOnClickListener(this);
        registerBinding.dobEt.setOnClickListener(this);
        registerBinding.countryEt.setOnClickListener(this);
        registerBinding.stateEt.setOnClickListener(this);
        registerBinding.cityEt.setOnClickListener(this);
        registerBinding.religionEt.setOnClickListener(this);
        registerBinding.motherTongueEt.setOnClickListener(this);
        registerBinding.maritalStatusEt.setOnClickListener(this);
        registerBinding.heightEt.setOnClickListener(this);
        registerBinding.foodEt.setOnClickListener(this);
        registerBinding.educationEt.setOnClickListener(this);
        registerBinding.educationFieldEt.setOnClickListener(this);
        registerBinding.occupationEt.setOnClickListener(this);
        registerBinding.occupationType.setOnClickListener(this);
        registerBinding.genderEt.setOnClickListener(this);

        FirebaseApp.initializeApp(this);

        networkConnectionCheck = new NetworkConnectionCheck(this);
        prefrenceManager = new PrefrenceManager(this);
        deviceID = Settings.System.getString(RegisterActivity.this.getContentResolver(), Settings.Secure.ANDROID_ID);
        geocoder = new Geocoder(this, Locale.getDefault());
        progressDialog = new ProgressDialog(this);
        FetchLocation();
        getDeviceToken();
        TextWatcher();


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.submit_btn:
                if (validationCheck()) {
                    if (networkConnectionCheck.isConnected()) {
                        Quick_blox_chatSignUp(email, f_name + " " + l_name, mobile_no);
                        AppUtils.closeKeyboard(this, view);
                    }
                }

                break;
            case R.id.gender_et:

                gender_dilog();

                break;
            case R.id.profile_iv:

                showPictureDialog();

                break;

            case R.id.dob_et:

                dob_pickDate();

                break;
            case R.id.profile_for_et:

                if (networkConnectionCheck.isConnected()) {
                    spinner_dilog("profile for");
                    profile_for_spinner_network_call();
                }

                break;

            case R.id.country_et:

                if (networkConnectionCheck.isConnected()) {
                    country_list_dilog("country");
                    country_spinner_network_call();
                }

                break;
            case R.id.state_et:
                String country_=registerBinding.countryEt.getText().toString();

                if (country_.equalsIgnoreCase("null")||country_.equalsIgnoreCase("")){
                    AppUtils.customeToastRed("Please select country first",this);
                }else {
                    if (networkConnectionCheck.isConnected()) {
                        state_list_dilog("state");
                        state_spinner_network_call();
                    }
                }

                break;
            case R.id.city_et:
                String country_1=registerBinding.countryEt.getText().toString();
                String state_=registerBinding.stateEt.getText().toString();

                if (country_1.equalsIgnoreCase("null")||country_1.equalsIgnoreCase("")){
                    AppUtils.customeToastRed("Please select country first",this);
                }else if (state_.equalsIgnoreCase("null")||state_.equalsIgnoreCase("")){
                    AppUtils.customeToastRed("Please select state first",this);
                }else {
                    if (networkConnectionCheck.isConnected()) {
                        city_list_dilog("city");
                        city_spinner_network_call();
                    }
                }

                break;
            case R.id.religion_et:

                if (networkConnectionCheck.isConnected()) {
                    spinner_dilog("religion");
                    religion_list_spinner_network_call();
                }

                break;
            case R.id.mother_tongue_et:

                if (networkConnectionCheck.isConnected()) {
                    spinner_dilog("mother tongue");
                    mother_tongue_list_spinner_network_call();
                }

                break;
            case R.id.marital_status_et:
                if (networkConnectionCheck.isConnected()) {
                    spinner_dilog("marital status");
                    marital_status_list_spinner_network_call();
                }


                break;
            case R.id.height_et:

                if (networkConnectionCheck.isConnected()) {
                    height_list_dilog("height");
                    height_list_network_call();
                }

                break;
            case R.id.food_et:

                if (networkConnectionCheck.isConnected()) {
                    spinner_dilog("food type");
                    food_list_spinner_network_call();
                }


                break;
            case R.id.education_et:

                if (networkConnectionCheck.isConnected()) {
                    education_list_dilog("education");
                    education_list_network_call();
                }

                break;
            case R.id.education_field_et:

                if (networkConnectionCheck.isConnected()) {
                    education_type_list_dilog("education type");
                    education_type_list_network_call();
                }

                break;
            case R.id.occupation_et:
                if (networkConnectionCheck.isConnected()) {
                    spinner_dilog("occupation");
                    occupation_list_spinner_network_call();
                }

                break;
            case R.id.occupation_type:

                if (networkConnectionCheck.isConnected()) {
                    spinner_dilog("occupation type");
                    occupation_type_list_spinner_network_call();
                }

                break;


            case R.id.terms_condition_chkBox:

                if (registerBinding.termsConditionChkBox.isChecked()) {

                    registerBinding.submitBtn.setAlpha(1f);
                    registerBinding.submitBtn.setClickable(true);
                    registerBinding.submitBtn.setEnabled(true);
                } else {
                    registerBinding.submitBtn.setAlpha(0.5f);
                    registerBinding.submitBtn.setClickable(false);
                    registerBinding.submitBtn.setEnabled(false);
                }


                try {

                    try {
                        lats = Double.parseDouble(latitude);
                        longst = Double.parseDouble(longitude);
                    }catch (NullPointerException e){
                        e.printStackTrace();
                    }

                    try {
                        addresses = geocoder.getFromLocation(lats, longst, 1);
                        String address_gps = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                        String city_gps = addresses.get(0).getLocality();
                        String state_gps = addresses.get(0).getAdminArea();
                        String country_gps = addresses.get(0).getCountryName();
                        String postalCode = addresses.get(0).getPostalCode();
                        String knownName = addresses.get(0).getFeatureName();
                        current_address = address_gps;
                    }catch (IndexOutOfBoundsException e){

                        e.printStackTrace();
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

                break;

            default:
                break;
        }
    }


    public void FetchLocation() {

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(10 * 1000); // 10 seconds
        locationRequest.setFastestInterval(5 * 1000); // 5 seconds

        new GpsUtils(this).turnGPSOn(new GpsUtils.onGpsListener() {
            @Override
            public void gpsStatus(boolean isGPSEnable) {
                // turn on GPS
                isGPS = isGPSEnable;
            }
        });


        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        wayLatitude = location.getLatitude();
                        wayLongitude = location.getLongitude();

                        if (!isContinue) {

                            latitude = String.format(Locale.US, "%s", wayLatitude);
                            longitude = String.format(Locale.US, "%s", wayLongitude);


                        } else {
                            stringBuilder.append(wayLatitude);
                            stringBuilder.append("-");
                            stringBuilder.append(wayLongitude);
                            stringBuilder.append("\n\n");
                        }
                        if (!isContinue && mFusedLocationClient != null) {
                            mFusedLocationClient.removeLocationUpdates(locationCallback);
                        }
                    }
                }
            }
        };

        if (!isGPS) {
            getLocation();
            return;
        }
        isContinue = false;

        getLocation();
    }


    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    AppConstant.LOCATION_REQUEST);

        } else {
            if (isContinue) {
                mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
            } else {
                mFusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @SuppressLint("MissingPermission")
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            wayLatitude = location.getLatitude();
                            wayLongitude = location.getLongitude();

                            latitude = String.format(Locale.US, "%s", wayLatitude);
                            longitude = String.format(Locale.US, "%s", wayLongitude);

                        } else {
                            mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
                        }
                    }
                });
            }
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1000: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (isContinue) {
                        mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
                    } else {
                        mFusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
                            @Override
                            public void onSuccess(Location location) {
                                if (location != null) {
                                    wayLatitude = location.getLatitude();
                                    wayLongitude = location.getLongitude();

                                    latitude = String.format(Locale.US, "%s", wayLatitude);
                                    longitude = String.format(Locale.US, "%s", wayLongitude);

                                } else {
                                    mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
                                }
                            }
                        });
                    }
                } else {
                    AppUtils.customeToastRed("Permission denied", getApplicationContext());
                }
                break;
            }
        }
    }

    private void getDeviceToken() {

        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w("", "getInstanceId failed", task.getException());
                            return;
                        }
                        // Get new Instance ID token
                        device_token = task.getResult().getToken();
                    }
                });
    }

    /*QUICK BLOX CHAT*/

    private void Quick_blox_chatSignUp(String email_id, String full_name, String phone) {
        progressDialog.setMessage("Please wait....");
        progressDialog.show();

        final QBUser user = new QBUser(email_id, "12345678");
        user.setEmail(email_id);
        user.setFullName(full_name);
        user.setPhone(phone);
        StringifyArrayList<String> tags = new StringifyArrayList<String>();
        tags.add("AmazingMarry");
        user.setTags(tags);
        user.setWebsite("https://amazingmarry.com/");
        QBUsers.signUp(user).performAsync(new QBEntityCallback<QBUser>() {
            @SuppressLint("LogNotTimber")
            @Override
            public void onSuccess(QBUser qbUser, Bundle bundle) {
                SharedPrefsHelper.getInstance().saveQbUser(user);
                Log.d("data==", String.valueOf(user.getId()));
                ChatLogin(email);
            }

            @Override
            public void onError(QBResponseException e) {
                progressDialog.dismiss();
                AppUtils.customeToastRed("This Email ID is Already Exists", getApplicationContext());
            }
        });
    }


    public void ChatLogin(String email) {
        final QBUser user = new QBUser(email, "12345678");
        ChatHelper.getInstance().login(user, new QBEntityCallback<Void>() {
            @Override
            public void onSuccess(Void result, Bundle bundle) {
                SharedPrefsHelper.getInstance().saveQbUser(user);
                Log.d("id==", String.valueOf(user.getId()));
                loginToChat(user, getApplicationContext());
            }

            @Override
            public void onError(QBResponseException e) {
            }
        });
    }

    private void loginToChat(final QBUser user, final Context context) {
        final String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        ChatHelper.getInstance().loginToChat(user, new QBEntityCallback<Void>() {
            @Override
            public void onSuccess(Void result, Bundle bundle) {
                //This method is calling to subscribe push notification

                String quickbloxId = String.valueOf(user.getId());
                create_biography_network_call(quickbloxId);
            }

            @Override
            public void onError(QBResponseException e) {
                Log.e("Chat login onError(): ", "" + e);

            }
        });

    }

    public void TextWatcher() {
        registerBinding.emailEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                email = registerBinding.emailEt.getText().toString();

                if (email.length() == 0) {

                    registerBinding.emailTxtInput.setBoxStrokeColor(ContextCompat.getColor(RegisterActivity.this, R.color.light_black));

                    registerBinding.submitBtn.setAlpha(0.5f);
                    registerBinding.submitBtn.setClickable(false);
                    registerBinding.submitBtn.setEnabled(false);
                } else if (AppUtils.isEmailValid(email)) {

                    registerBinding.emailTxtInput.setBoxStrokeColor(ContextCompat.getColor(RegisterActivity.this, R.color.toast_txtColour_green));

                    registerBinding.submitBtn.setAlpha(1f);
                    registerBinding.submitBtn.setClickable(true);
                    registerBinding.submitBtn.setEnabled(true);

                } else {
                    registerBinding.emailTxtInput.setBoxStrokeColor(ContextCompat.getColor(RegisterActivity.this, R.color.toast_txtColour_red));

                    registerBinding.submitBtn.setAlpha(0.5f);
                    registerBinding.submitBtn.setClickable(false);
                    registerBinding.submitBtn.setEnabled(false);
                }

            }
        });

        registerBinding.contactNoEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                mobile_no = registerBinding.contactNoEt.getText().toString();

                if (mobile_no.length() == 0) {

                    registerBinding.contactN0TxtInput.setBoxStrokeColor(ContextCompat.getColor(RegisterActivity.this, R.color.light_black));

                    registerBinding.submitBtn.setAlpha(0.5f);
                    registerBinding.submitBtn.setClickable(false);
                    registerBinding.submitBtn.setEnabled(false);

                } else if (mobile_no.length() == 10) {

                    registerBinding.contactN0TxtInput.setBoxStrokeColor(ContextCompat.getColor(RegisterActivity.this, R.color.toast_txtColour_green));

                    registerBinding.submitBtn.setAlpha(1f);
                    registerBinding.submitBtn.setClickable(true);
                    registerBinding.submitBtn.setEnabled(true);

                } else {
                    registerBinding.contactN0TxtInput.setBoxStrokeColor(ContextCompat.getColor(RegisterActivity.this, R.color.toast_txtColour_red));

                    registerBinding.submitBtn.setAlpha(0.5f);
                    registerBinding.submitBtn.setClickable(false);
                    registerBinding.submitBtn.setEnabled(false);
                }

            }
        });


        registerBinding.passwordEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                password = registerBinding.passwordEt.getText().toString();

                if (password.length() == 0) {

                    registerBinding.passwordTxtInput.setBoxStrokeColor(ContextCompat.getColor(RegisterActivity.this, R.color.light_black));

                    registerBinding.submitBtn.setAlpha(0.5f);
                    registerBinding.submitBtn.setClickable(false);
                    registerBinding.submitBtn.setEnabled(false);
                } else if (password.length() < 6 || password.length() > 15) {

                    registerBinding.passwordTxtInput.setBoxStrokeColor(ContextCompat.getColor(RegisterActivity.this, R.color.toast_txtColour_red));

                    registerBinding.submitBtn.setAlpha(1f);
                    registerBinding.submitBtn.setClickable(true);
                    registerBinding.submitBtn.setEnabled(true);

                } else {
                    registerBinding.passwordTxtInput.setBoxStrokeColor(ContextCompat.getColor(RegisterActivity.this, R.color.toast_txtColour_green));

                    registerBinding.submitBtn.setAlpha(0.5f);
                    registerBinding.submitBtn.setClickable(false);
                    registerBinding.submitBtn.setEnabled(false);
                }

            }
        });

    }

    private void showPictureDialog() {
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(RegisterActivity.this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera"};
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallary();
                                break;
                            case 1:
                                takePhotoFromCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

    public void choosePhotoFromGallary() {
        if (PackageManager.PERMISSION_GRANTED
                == ActivityCompat.checkSelfPermission(RegisterActivity.this,
                Manifest.permission.CAMERA) && PackageManager.PERMISSION_GRANTED
                == ActivityCompat.checkSelfPermission(RegisterActivity.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(galleryIntent, GALLERY);
        } else {
            requestWritePermission(RegisterActivity.this);

        }
    }

    private void takePhotoFromCamera() {
        if (PackageManager.PERMISSION_GRANTED
                == ActivityCompat.checkSelfPermission(RegisterActivity.this,
                Manifest.permission.CAMERA) && PackageManager.PERMISSION_GRANTED
                == ActivityCompat.checkSelfPermission(RegisterActivity.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, CAMERA);
        } else {

            requestWritePermission(RegisterActivity.this);
        }
    }

    private static void requestWritePermission(final Context context) {
        if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.CAMERA)) {
            new android.app.AlertDialog.Builder(context)
                    .setMessage("This app needs permission to use The phone Camera in order to activate the Scanner")
                    .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.CAMERA}, 1);
                        }
                    }).show();

        } else if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            new android.app.AlertDialog.Builder(context)
                    .setMessage("This app needs permission to use storage to save the clicked Image")
                    .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                        }
                    }).show();

        } else {
            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                contentURI = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(RegisterActivity.this.getContentResolver(), contentURI);
                    String path = saveImage(bitmap);

                    registerBinding.profileIv.setImageBitmap(bitmap);

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] b = baos.toByteArray();

                    String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);


                    Log.d("", "onActivityResult: " + bitmap);


                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(RegisterActivity.this, "Failed!", Toast.LENGTH_SHORT).show();
                }
            }
        } else if (requestCode == CAMERA) {
            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");

            contentURI=getImageUri(RegisterActivity.this,thumbnail);

            registerBinding.profileIv.setImageBitmap(thumbnail);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] b = baos.toByteArray();

            String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
            saveImage(thumbnail);
        }
    }

    public String saveImage(Bitmap myBitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        myBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File wallpaperDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }
        try {
            File f = new File(wallpaperDirectory, Calendar.getInstance()
                    .getTimeInMillis() + ".jpg");
            f.createNewFile();
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(RegisterActivity.this,
                    new String[]{f.getPath()},
                    new String[]{"image/jpeg"}, null);
            fo.close();
            Log.e("TAG", "File Saved::--->" + f.getAbsolutePath());
            imagepath = f.getAbsolutePath();

            // saveProfileAccount();
            return f.getAbsolutePath();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return "";
    }

    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        CursorLoader loader = new CursorLoader(this, contentUri, proj, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String result = cursor.getString(column_index);
        cursor.close();
        return result;
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public void create_biography_network_call(String quick_blox_id) {

        File file = new File(getRealPathFromURI(contentURI));
        RequestBody requestFile = RequestBody.create(MediaType.parse(getContentResolver().getType(contentURI)), file);
        RequestBody apikey = RequestBody.create(MediaType.parse("multipart/form-data"), AppConstant.apikey);
        RequestBody v_code = RequestBody.create(MediaType.parse("multipart/form-data"), AppConstant.v_code);
        RequestBody deviceType = RequestBody.create(MediaType.parse("multipart/form-data"), AppConstant.deviceType);
        RequestBody device_ID = RequestBody.create(MediaType.parse("multipart/form-data"), deviceID);
        RequestBody deviceToken = RequestBody.create(MediaType.parse("multipart/form-data"), device_token);
        RequestBody quick_bloxId = RequestBody.create(MediaType.parse("multipart/form-data"), quick_blox_id);
        RequestBody lat = RequestBody.create(MediaType.parse("multipart/form-data"), latitude);
        RequestBody longs = RequestBody.create(MediaType.parse("multipart/form-data"), longitude);
        RequestBody address = RequestBody.create(MediaType.parse("multipart/form-data"), current_address);
        RequestBody first_name = RequestBody.create(MediaType.parse("multipart/form-data"), f_name);
        RequestBody last_name = RequestBody.create(MediaType.parse("multipart/form-data"), l_name);
        RequestBody email_id = RequestBody.create(MediaType.parse("multipart/form-data"), email);
        RequestBody pass = RequestBody.create(MediaType.parse("multipart/form-data"), password);
        RequestBody mob_no = RequestBody.create(MediaType.parse("multipart/form-data"), mobile_no);
        RequestBody gen = RequestBody.create(MediaType.parse("multipart/form-data"), gender);
        RequestBody prfile_for = RequestBody.create(MediaType.parse("multipart/form-data"), profile_for);
        RequestBody dob_day = RequestBody.create(MediaType.parse("multipart/form-data"), dob);
        RequestBody city_ = RequestBody.create(MediaType.parse("multipart/form-data"), city);
        RequestBody state_ = RequestBody.create(MediaType.parse("multipart/form-data"), state);
        RequestBody country_ = RequestBody.create(MediaType.parse("multipart/form-data"), country);
        RequestBody education_category = RequestBody.create(MediaType.parse("multipart/form-data"), education);
        RequestBody qualification = RequestBody.create(MediaType.parse("multipart/form-data"), education_field);
        RequestBody hobbiy = RequestBody.create(MediaType.parse("multipart/form-data"), hobbies);
        RequestBody fv_actor = RequestBody.create(MediaType.parse("multipart/form-data"), fav_actor);
        RequestBody fv_actress = RequestBody.create(MediaType.parse("multipart/form-data"), fav_actress);
        RequestBody food_type = RequestBody.create(MediaType.parse("multipart/form-data"), food);
        RequestBody partner = RequestBody.create(MediaType.parse("multipart/form-data"), partner_type);
        RequestBody mthr_tongue = RequestBody.create(MediaType.parse("multipart/form-data"), mother_tongue);
        RequestBody mrtial_status = RequestBody.create(MediaType.parse("multipart/form-data"), marital_status);
        RequestBody occupation_sector = RequestBody.create(MediaType.parse("multipart/form-data"), occupation);
        RequestBody occup_type = RequestBody.create(MediaType.parse("multipart/form-data"), occupation_type);
        RequestBody rligion = RequestBody.create(MediaType.parse("multipart/form-data"), religion);
        RequestBody hight = RequestBody.create(MediaType.parse("multipart/form-data"), height);
        RequestBody caste_ = RequestBody.create(MediaType.parse("multipart/form-data"), caste);

        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<RegisterModel> registerModelCall = ((RestInterfaces) iRestInterfaces).registerUser(requestFile, apikey, v_code, deviceType, device_ID, deviceToken, quick_bloxId, lat, longs, address, first_name, last_name, email_id, pass,
                mob_no, gen, prfile_for, dob_day, city_, state_, country_, education_category, qualification, hobbiy, fv_actor, fv_actress, food_type, partner, mthr_tongue, mrtial_status, occupation_sector, occup_type, rligion, hight, caste_);
        registerModelCall.enqueue(new Callback<RegisterModel>() {
            @Override
            public void onResponse(Call<RegisterModel> call, Response<RegisterModel> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    Log.w("register_response ", new GsonBuilder().setPrettyPrinting().create().toJson(response));
                    AppUtils.customeToastGreen(response.body().getMessage(), getApplicationContext());
                    Intent intent1 = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent1);

                }else {
                    AppUtils.customeToastRed(response.body().getMessage(), getApplicationContext());
                }
            }

            @Override
            public void onFailure(Call<RegisterModel> call, Throwable t) {

                progressDialog.dismiss();
            }
        });
    }

    public boolean validationCheck() {
        boolean check = false;

        f_name = Objects.requireNonNull(registerBinding.fNameEt.getText()).toString();
        l_name = Objects.requireNonNull(registerBinding.lNameEt.getText()).toString();
        email = Objects.requireNonNull(registerBinding.emailEt.getText()).toString();
        password = Objects.requireNonNull(registerBinding.passwordEt.getText()).toString();
        mobile_no = Objects.requireNonNull(registerBinding.contactNoEt.getText()).toString();
        profile_for = Objects.requireNonNull(registerBinding.profileForEt.getText()).toString();
        dob = Objects.requireNonNull(registerBinding.dobEt.getText()).toString();
        country = Objects.requireNonNull(registerBinding.countryEt.getText()).toString();
        state = Objects.requireNonNull(registerBinding.stateEt.getText()).toString();
        city = Objects.requireNonNull(registerBinding.cityEt.getText()).toString();
        hobbies = Objects.requireNonNull(registerBinding.hobbiesEt.getText()).toString();
        fav_actor = Objects.requireNonNull(registerBinding.favActorEt.getText()).toString();
        fav_actress = Objects.requireNonNull(registerBinding.favActressEt.getText()).toString();
        caste = Objects.requireNonNull(registerBinding.casteEt.getText()).toString();
        religion = Objects.requireNonNull(registerBinding.religionEt.getText()).toString();
        mother_tongue = Objects.requireNonNull(registerBinding.motherTongueEt.getText()).toString();
        marital_status = Objects.requireNonNull(registerBinding.maritalStatusEt.getText()).toString();
        height = Objects.requireNonNull(registerBinding.heightEt.getText()).toString();
        food = Objects.requireNonNull(registerBinding.foodEt.getText()).toString();
        education = Objects.requireNonNull(registerBinding.educationEt.getText()).toString();
        education_field = Objects.requireNonNull(registerBinding.educationFieldEt.getText()).toString();
        occupation = Objects.requireNonNull(registerBinding.occupationEt.getText()).toString();
        occupation_type = Objects.requireNonNull(registerBinding.occupationType.getText()).toString();
        partner_type = Objects.requireNonNull(registerBinding.partnerLikeEt.getText()).toString();

        if (check == false) {

            if (contentURI == null) {
                AppUtils.customeToastRed("Please select profile picture first", getApplicationContext());
            }else if (f_name.equals("")) {
                registerBinding.fNameEt.requestFocus();
                registerBinding.fNameEt.setError("First name should not be blank");
            } else if (l_name.equals("")) {
                registerBinding.lNameEt.requestFocus();
                registerBinding.lNameEt.setError("Last name should not be blank");
            } else if (email.equals("")) {
                registerBinding.emailEt.requestFocus();
                registerBinding.emailEt.setError("Email should not be blank");
            } else if ((!AppUtils.isEmailValid(email))) {
                registerBinding.emailEt.requestFocus();
                registerBinding.emailEt.setError("Please enter correct email");
            } else if (password.equals("")) {
                registerBinding.passwordEt.requestFocus();
                registerBinding.passwordEt.setError("Password should not be blank");
            } else if (password.length() < 6 || password.length() > 15) {
                registerBinding.passwordEt.requestFocus();
                registerBinding.passwordEt.setError("Password should not be less than 6 digit");
            } else if (mobile_no.equals("")) {
                registerBinding.contactNoEt.requestFocus();
                registerBinding.contactNoEt.setError("Contact no should not be blank");
            } else if (!AppUtils.isValidMobile(mobile_no)) {
                registerBinding.contactNoEt.requestFocus();
                registerBinding.contactNoEt.setError("Please enter correct mobile no");
            } else if (gender.equals("")) {
                AppUtils.customeToastRed("Please select gender", getApplicationContext());
            } else if (profile_for.equals("")) {
                AppUtils.customeToastRed("Please select profile for", getApplicationContext());
            } else if (dob.equals("")) {
                AppUtils.customeToastRed("Please select date of birth", getApplicationContext());
            } else if (country.equals("")) {
                AppUtils.customeToastRed("Please select country", getApplicationContext());
            } else if (state.equals("")) {
                AppUtils.customeToastRed("Please select state", getApplicationContext());
            } else if (city.equals("")) {
                AppUtils.customeToastRed("Please select city", getApplicationContext());
            } else if (hobbies.equals("")) {
                registerBinding.hobbiesEt.requestFocus();
                registerBinding.hobbiesEt.setError("Hobbies should not be blank");
            } else if (fav_actor.equals("")) {
                registerBinding.favActorEt.requestFocus();
                registerBinding.favActorEt.setError("Favourite actor should not be blank");
            } else if (fav_actress.equals("")) {
                registerBinding.favActressEt.requestFocus();
                registerBinding.favActressEt.setError("Favourite actress should not be blank");
            } else if (caste.equals("")) {
                registerBinding.casteEt.requestFocus();
                registerBinding.casteEt.setError("Caste should not be blank");
            } else if (religion.equals("")) {
                AppUtils.customeToastRed("Please select religion", getApplicationContext());
            } else if (mother_tongue.equals("")) {
                AppUtils.customeToastRed("Please select mother tongue", getApplicationContext());
            } else if (marital_status.equals("")) {
                AppUtils.customeToastRed("Please select marital status", getApplicationContext());
            } else if (height.equals("")) {
                AppUtils.customeToastRed("Please select height", getApplicationContext());
            } else if (food.equals("")) {
                AppUtils.customeToastRed("Please select food type", getApplicationContext());
            } else if (education.equals("")) {
                AppUtils.customeToastRed("Please select education", getApplicationContext());
            } else if (education_field.equals("")) {
                AppUtils.customeToastRed("Please select education field", getApplicationContext());
            } else if (occupation.equals("")) {
                AppUtils.customeToastRed("Please select occupation", getApplicationContext());
            } else if (occupation_type.equals("")) {
                AppUtils.customeToastRed("Please select occupation type", getApplicationContext());
            } else if (partner_type.equals("")) {
                registerBinding.partnerLikeEt.requestFocus();
                registerBinding.partnerLikeEt.setError("Partner type should not be blank");
            } else {

                check = true;
            }
        }
        return check;
    }

    public void gender_dilog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.gender_type_dilogs, null);
        ImageView close_iv = dialogView.findViewById(R.id.close_iv);
        CardView male_cv = dialogView.findViewById(R.id.male_cv);
        CardView female_cv = dialogView.findViewById(R.id.female_cv);

        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();

        close_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                dialog.cancel();

            }
        });
        male_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                gender = "MALE";
                registerBinding.genderEt.setText("Male");
                dialog.cancel();

            }
        });
        female_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                gender = "FEMALE";
                registerBinding.genderEt.setText("Female");
                dialog.cancel();
            }
        });


        dialog.show();
    }


    public void spinner_dilog(final String dilogs_name) {


        AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.spinner_dialogs, null);
        recycler_view = dialogView.findViewById(R.id.recycler_view);
        ImageView close_iv = dialogView.findViewById(R.id.close_iv);
        tvNoData = dialogView.findViewById(R.id.tvNoData);
        TextView titel_tv = dialogView.findViewById(R.id.titel_tv);
        search_edtText = dialogView.findViewById(R.id.search_edtText);
        myprogressbar = dialogView.findViewById(R.id.p_bar);
        RelativeLayout search_rl = dialogView.findViewById(R.id.search_rl);
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));

        spinnerModelList = new ArrayList<>();


        titel_tv.setText("Select " + dilogs_name);


        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();


        search_edtText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                try {
                    spinnerAdapter.filter(charSequence.toString().toLowerCase());
                    // checkNoDataCase();
                } catch (Exception e) {

                    Log.d("", "onTextChanged: " + e);
                }

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        close_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                dialog.cancel();

            }
        });

        iCallback = new ICallback() {
            @Override
            public void onItemClick(int pos) {

                spinner_list_name = spinnerModelList.get(pos).getName();

                if (dilogs_name.equalsIgnoreCase("profile for")) {
                    registerBinding.profileForEt.setText(spinner_list_name);
                } else if (dilogs_name.equalsIgnoreCase("religion")) {
                    registerBinding.religionEt.setText(spinner_list_name);
                } else if (dilogs_name.equalsIgnoreCase("mother tongue")) {
                    registerBinding.motherTongueEt.setText(spinner_list_name);
                } else if (dilogs_name.equalsIgnoreCase("occupation")) {
                    registerBinding.occupationEt.setText(spinner_list_name);
                } else if (dilogs_name.equalsIgnoreCase("occupation type")) {
                    registerBinding.occupationType.setText(spinner_list_name);
                } else if (dilogs_name.equalsIgnoreCase("food type")) {
                    registerBinding.foodEt.setText(spinner_list_name);
                } else if (dilogs_name.equalsIgnoreCase("marital status")) {
                    registerBinding.maritalStatusEt.setText(spinner_list_name);
                }

                AppUtils.hideKeyboard(RegisterActivity.this);


                dialog.cancel();

            }
        };

        dialog.show();
    }


    public void country_list_dilog(final String dilogs_name) {


        AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.spinner_dialogs, null);
        recycler_view = dialogView.findViewById(R.id.recycler_view);
        ImageView close_iv = dialogView.findViewById(R.id.close_iv);
        tvNoData = dialogView.findViewById(R.id.tvNoData);
        TextView titel_tv = dialogView.findViewById(R.id.titel_tv);
        search_edtText = dialogView.findViewById(R.id.search_edtText);
        myprogressbar = dialogView.findViewById(R.id.p_bar);
        RelativeLayout search_rl = dialogView.findViewById(R.id.search_rl);
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));

        country_list = new ArrayList<>();


        titel_tv.setText("Select " + dilogs_name);

        search_rl.setVisibility(View.VISIBLE);

        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();


        search_edtText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                try {
                    countryAdapter.filter(charSequence.toString().toLowerCase());
                    // checkNoDataCase();
                } catch (Exception e) {

                    Log.d("", "onTextChanged: " + e);
                }

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        close_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                dialog.cancel();

            }
        });

        iCallback = new ICallback() {
            @Override
            public void onItemClick(int pos) {

                spinner_list_name = country_list.get(pos).getName();
                country_id=country_list.get(pos).getCountryId();
                registerBinding.countryEt.setText(spinner_list_name);


                AppUtils.hideKeyboard(RegisterActivity.this);


                dialog.cancel();

            }
        };

        dialog.show();
    }

    public void state_list_dilog(final String dilogs_name) {


        AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.spinner_dialogs, null);
        recycler_view = dialogView.findViewById(R.id.recycler_view);
        ImageView close_iv = dialogView.findViewById(R.id.close_iv);
        tvNoData = dialogView.findViewById(R.id.tvNoData);
        TextView titel_tv = dialogView.findViewById(R.id.titel_tv);
        search_edtText = dialogView.findViewById(R.id.search_edtText);
        myprogressbar = dialogView.findViewById(R.id.p_bar);
        RelativeLayout search_rl = dialogView.findViewById(R.id.search_rl);
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));

        state_list = new ArrayList<>();


        titel_tv.setText("Select " + dilogs_name);

        search_rl.setVisibility(View.VISIBLE);

        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();


        search_edtText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                try {
                    stateAdapter.filter(charSequence.toString().toLowerCase());
                    // checkNoDataCase();
                } catch (Exception e) {

                    Log.d("", "onTextChanged: " + e);
                }

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        close_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                dialog.cancel();

            }
        });

        iCallback = new ICallback() {
            @Override
            public void onItemClick(int pos) {

                spinner_list_name = state_list.get(pos).getName();
                state_id = state_list.get(pos).getId();
                registerBinding.stateEt.setText(spinner_list_name);

                AppUtils.hideKeyboard(RegisterActivity.this);


                dialog.cancel();

            }
        };

        dialog.show();
    }

    public void city_list_dilog(final String dilogs_name) {


        AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.spinner_dialogs, null);
        recycler_view = dialogView.findViewById(R.id.recycler_view);
        ImageView close_iv = dialogView.findViewById(R.id.close_iv);
        tvNoData = dialogView.findViewById(R.id.tvNoData);
        TextView titel_tv = dialogView.findViewById(R.id.titel_tv);
        search_edtText = dialogView.findViewById(R.id.search_edtText);
        myprogressbar = dialogView.findViewById(R.id.p_bar);
        RelativeLayout search_rl = dialogView.findViewById(R.id.search_rl);
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));

        city_list = new ArrayList<>();


        titel_tv.setText("Select " + dilogs_name);

        search_rl.setVisibility(View.VISIBLE);

        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();


        search_edtText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                try {
                    cityAdapter.filter(charSequence.toString().toLowerCase());
                    // checkNoDataCase();
                } catch (Exception e) {

                    Log.d("", "onTextChanged: " + e);
                }

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        close_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                dialog.cancel();

            }
        });

        iCallback = new ICallback() {
            @Override
            public void onItemClick(int pos) {

                spinner_list_name = city_list.get(pos).getName();

                registerBinding.cityEt.setText(spinner_list_name);

                AppUtils.hideKeyboard(RegisterActivity.this);

                dialog.cancel();

            }
        };

        dialog.show();
    }

    public void education_list_dilog(final String dilogs_name) {


        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.spinner_dialogs, null);
        recycler_view = dialogView.findViewById(R.id.recycler_view);
        ImageView close_iv = dialogView.findViewById(R.id.close_iv);
        tvNoData = dialogView.findViewById(R.id.tvNoData);
        TextView titel_tv = dialogView.findViewById(R.id.titel_tv);
        search_edtText = dialogView.findViewById(R.id.search_edtText);
        myprogressbar = dialogView.findViewById(R.id.p_bar);
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));

        education_list = new ArrayList<>();


        titel_tv.setText("Select " + dilogs_name);

        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();


        search_edtText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                try {
                    educationAdapter.filter(charSequence.toString().toLowerCase());
                    // checkNoDataCase();
                } catch (Exception e) {

                    Log.d("", "onTextChanged: " + e);
                }

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        close_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                dialog.cancel();

            }
        });

        iCallback = new ICallback() {
            @Override
            public void onItemClick(int pos) {

                spinner_list_name = education_list.get(pos).getEducationlevelName();

                registerBinding.educationEt.setText(spinner_list_name);


                AppUtils.hideKeyboard(RegisterActivity.this);


                dialog.cancel();

            }
        };

        dialog.show();
    }

    public void education_type_list_dilog(final String dilogs_name) {


        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.spinner_dialogs, null);
        recycler_view = dialogView.findViewById(R.id.recycler_view);
        ImageView close_iv = dialogView.findViewById(R.id.close_iv);
        tvNoData = dialogView.findViewById(R.id.tvNoData);
        TextView titel_tv = dialogView.findViewById(R.id.titel_tv);
        search_edtText = dialogView.findViewById(R.id.search_edtText);
        myprogressbar = dialogView.findViewById(R.id.p_bar);
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));

        education_type_list = new ArrayList<>();


        titel_tv.setText("Select " + dilogs_name);

        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();


        search_edtText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                try {
                    educationTypeAdapter.filter(charSequence.toString().toLowerCase());
                    // checkNoDataCase();
                } catch (Exception e) {

                    Log.d("", "onTextChanged: " + e);
                }

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        close_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                dialog.cancel();

            }
        });

        iCallback = new ICallback() {
            @Override
            public void onItemClick(int pos) {

                spinner_list_name = education_type_list.get(pos).getQualificationIn();

                registerBinding.educationFieldEt.setText(spinner_list_name);


                AppUtils.hideKeyboard(RegisterActivity.this);


                dialog.cancel();

            }
        };

        dialog.show();
    }

    public void height_list_dilog(final String dilogs_name) {


        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.spinner_dialogs, null);
        recycler_view = dialogView.findViewById(R.id.recycler_view);
        ImageView close_iv = dialogView.findViewById(R.id.close_iv);
        tvNoData = dialogView.findViewById(R.id.tvNoData);
        TextView titel_tv = dialogView.findViewById(R.id.titel_tv);
        search_edtText = dialogView.findViewById(R.id.search_edtText);
        myprogressbar = dialogView.findViewById(R.id.p_bar);
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));

        height_list = new ArrayList<>();


        titel_tv.setText("Select " + dilogs_name);

        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();


        search_edtText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                try {
                    heightAdapter.filter(charSequence.toString().toLowerCase());
                    // checkNoDataCase();
                } catch (Exception e) {

                    Log.d("", "onTextChanged: " + e);
                }

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        close_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the alert dialog
                dialog.cancel();

            }
        });

        iCallback = new ICallback() {
            @Override
            public void onItemClick(int pos) {

                spinner_list_name = height_list.get(pos).getHeight();

                registerBinding.heightEt.setText(spinner_list_name);


                AppUtils.hideKeyboard(RegisterActivity.this);


                dialog.cancel();

            }
        };

        dialog.show();
    }


    public void dob_pickDate() {

        mcurrentDate = Calendar.getInstance();
        year = mcurrentDate.get(Calendar.YEAR);
        month = mcurrentDate.get(Calendar.MONTH);
        day = mcurrentDate.get(Calendar.DAY_OF_MONTH);


        final DatePickerDialog mDatePicker = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {


                int yrr = selectedyear;
                int monn = selectedmonth;
                int dayy = selectedday;

                registerBinding.dobEt.setText(formatDate(yrr, monn, dayy));


            }
        }, year, month, day);
        mDatePicker.setTitle("Please select date");
        // TODO Hide Future Date Here
        mDatePicker.getDatePicker().setMaxDate(System.currentTimeMillis());

        // TODO Hide Past Date Here
        //  mDatePicker.getDatePicker().setMinDate(System.currentTimeMillis());
        mDatePicker.show();
    }

    private static String formatDate(int year, int month, int day) {

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(0);
        cal.set(year, month, day);
        Date date = cal.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");

        return sdf.format(date);
    }


    public void profile_for_spinner_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<SpinnerModel> getCategWithOutOtherModelCall = iRestInterfaces.spinner_list();
        getCategWithOutOtherModelCall.enqueue(new Callback<SpinnerModel>() {
            @Override
            public void onResponse(Call<SpinnerModel> call, Response<SpinnerModel> response) {
                if (response.isSuccessful()) {
                    myprogressbar.setVisibility(View.GONE);
                    spinnerAdapter = new SpinnerAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    spinnerModelList.addAll(response.body().getResponse());
                    recycler_view.setAdapter(spinnerAdapter);
                    spinnerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<SpinnerModel> call, Throwable t) {
                myprogressbar.setVisibility(View.VISIBLE);
            }
        });

    }

    public void mother_tongue_list_spinner_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<SpinnerModel> getCategWithOutOtherModelCall = iRestInterfaces.mother_tongue_list();
        getCategWithOutOtherModelCall.enqueue(new Callback<SpinnerModel>() {
            @Override
            public void onResponse(Call<SpinnerModel> call, Response<SpinnerModel> response) {
                if (response.isSuccessful()) {
                    myprogressbar.setVisibility(View.GONE);
                    spinnerAdapter = new SpinnerAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    spinnerModelList.addAll(response.body().getResponse());
                    recycler_view.setAdapter(spinnerAdapter);
                    spinnerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<SpinnerModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);
            }
        });

    }

    public void religion_list_spinner_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<SpinnerModel> getCategWithOutOtherModelCall = iRestInterfaces.religion_list();
        getCategWithOutOtherModelCall.enqueue(new Callback<SpinnerModel>() {
            @Override
            public void onResponse(Call<SpinnerModel> call, Response<SpinnerModel> response) {
                if (response.isSuccessful()) {
                    myprogressbar.setVisibility(View.GONE);
                    spinnerAdapter = new SpinnerAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    spinnerModelList.addAll(response.body().getResponse());
                    recycler_view.setAdapter(spinnerAdapter);
                    spinnerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<SpinnerModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);
            }
        });

    }

    public void occupation_list_spinner_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<SpinnerModel> getCategWithOutOtherModelCall = iRestInterfaces.occupation();
        getCategWithOutOtherModelCall.enqueue(new Callback<SpinnerModel>() {
            @Override
            public void onResponse(Call<SpinnerModel> call, Response<SpinnerModel> response) {
                if (response.isSuccessful()) {
                    myprogressbar.setVisibility(View.GONE);
                    spinnerAdapter = new SpinnerAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    spinnerModelList.addAll(response.body().getResponse());
                    recycler_view.setAdapter(spinnerAdapter);
                    spinnerAdapter.notifyDataSetChanged();

                }
            }

            @Override
            public void onFailure(Call<SpinnerModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);
            }
        });

    }

    public void occupation_type_list_spinner_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<SpinnerModel> getCategWithOutOtherModelCall = iRestInterfaces.occupationType();
        getCategWithOutOtherModelCall.enqueue(new Callback<SpinnerModel>() {
            @Override
            public void onResponse(Call<SpinnerModel> call, Response<SpinnerModel> response) {
                if (response.isSuccessful()) {
                    myprogressbar.setVisibility(View.GONE);
                    spinnerAdapter = new SpinnerAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    spinnerModelList.addAll(response.body().getResponse());
                    recycler_view.setAdapter(spinnerAdapter);
                    spinnerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<SpinnerModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);
            }
        });

    }

    public void country_spinner_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<CountryModel> countryModelCall = iRestInterfaces.countryList();
        countryModelCall.enqueue(new Callback<CountryModel>() {
            @Override
            public void onResponse(Call<CountryModel> call, Response<CountryModel> response) {
                if (response.isSuccessful()) {
                    Log.w("country_response ", new GsonBuilder().setPrettyPrinting().create().toJson(response));
                    myprogressbar.setVisibility(View.GONE);
                    countryAdapter = new CountryAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    country_list.addAll(response.body().getResponse());
                    recycler_view.setAdapter(countryAdapter);
                    countryAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<CountryModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);

                Toast.makeText(RegisterActivity.this, ""+t, Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void state_spinner_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        Map<String, Object> paramObject = new ArrayMap<>();
        paramObject.put("country_id", country_id);
        Log.d("", "state_request: " + paramObject.toString());
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse(AppConstant.json_type), (new JSONObject(paramObject)).toString());
        Call<StateModel> stateModelCall = iRestInterfaces.stateList(body);
        stateModelCall.enqueue(new Callback<StateModel>() {
            @Override
            public void onResponse(Call<StateModel> call, Response<StateModel> response) {
                if (response.isSuccessful()) {
                    Log.w("state_response ", new GsonBuilder().setPrettyPrinting().create().toJson(response));
                    myprogressbar.setVisibility(View.GONE);
                    state_list.clear();
                    stateAdapter = new StateAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    state_list.addAll(response.body().getResponse());
                    recycler_view.setAdapter(stateAdapter);
                    stateAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<StateModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);
            }
        });

    }

    public void city_spinner_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        Map<String, Object> paramObject = new ArrayMap<>();
        paramObject.put("state_id", state_id);
        Log.d("", "city_request: " + paramObject.toString());
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse(AppConstant.json_type), (new JSONObject(paramObject)).toString());
        Call<CityModel> cityModelCall = iRestInterfaces.cityList(body);
        cityModelCall.enqueue(new Callback<CityModel>() {
            @Override
            public void onResponse(Call<CityModel> call, Response<CityModel> response) {
                if (response.isSuccessful()) {
                    Log.w("city_response ", new GsonBuilder().setPrettyPrinting().create().toJson(response));
                    myprogressbar.setVisibility(View.GONE);
                    city_list.clear();
                    cityAdapter = new CityAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    city_list.addAll(response.body().getResponse());
                    recycler_view.setAdapter(cityAdapter);
                    cityAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<CityModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);
            }
        });

    }

    public void education_list_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<EducationModel> educationModelCall = iRestInterfaces.education();
        educationModelCall.enqueue(new Callback<EducationModel>() {
            @Override
            public void onResponse(Call<EducationModel> call, Response<EducationModel> response) {
                if (response.isSuccessful()) {
                    myprogressbar.setVisibility(View.GONE);
                    educationAdapter = new EducationAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    education_list.addAll(response.body().getResponse());
                    recycler_view.setAdapter(educationAdapter);
                    educationAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<EducationModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);

            }
        });

    }

    public void education_type_list_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<EducationFieldModel> educationFieldModelCall = iRestInterfaces.educationField();
        educationFieldModelCall.enqueue(new Callback<EducationFieldModel>() {
            @Override
            public void onResponse(Call<EducationFieldModel> call, Response<EducationFieldModel> response) {
                if (response.isSuccessful()) {
                    myprogressbar.setVisibility(View.GONE);
                    educationTypeAdapter = new EducationTypeAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    education_type_list.addAll(response.body().getResponse());
                    recycler_view.setAdapter(educationTypeAdapter);
                    educationTypeAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<EducationFieldModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);
            }
        });

    }

    public void height_list_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<HeightModel> heightModelCall = iRestInterfaces.height();
        heightModelCall.enqueue(new Callback<HeightModel>() {
            @Override
            public void onResponse(Call<HeightModel> call, Response<HeightModel> response) {
                if (response.isSuccessful()) {
                    myprogressbar.setVisibility(View.GONE);
                    heightAdapter = new HeightAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    height_list.addAll(response.body().getResponse());
                    recycler_view.setAdapter(heightAdapter);
                    heightAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<HeightModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);
            }
        });

    }

    public void food_list_spinner_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<SpinnerModel> getCategWithOutOtherModelCall = iRestInterfaces.food_type();
        getCategWithOutOtherModelCall.enqueue(new Callback<SpinnerModel>() {
            @Override
            public void onResponse(Call<SpinnerModel> call, Response<SpinnerModel> response) {
                if (response.isSuccessful()) {
                    myprogressbar.setVisibility(View.GONE);
                    spinnerAdapter = new SpinnerAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    spinnerModelList.addAll(response.body().getResponse());
                    recycler_view.setAdapter(spinnerAdapter);
                    spinnerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<SpinnerModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);
            }
        });

    }

    public void marital_status_list_spinner_network_call() {
        myprogressbar.setVisibility(View.VISIBLE);
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        Call<SpinnerModel> getCategWithOutOtherModelCall = iRestInterfaces.marital_status();
        getCategWithOutOtherModelCall.enqueue(new Callback<SpinnerModel>() {
            @Override
            public void onResponse(Call<SpinnerModel> call, Response<SpinnerModel> response) {
                if (response.isSuccessful()) {
                    myprogressbar.setVisibility(View.GONE);
                    spinnerAdapter = new SpinnerAdapter(response.body().getResponse(), getApplicationContext(), iCallback);
                    spinnerModelList.addAll(response.body().getResponse());
                    recycler_view.setAdapter(spinnerAdapter);
                    spinnerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<SpinnerModel> call, Throwable t) {
                myprogressbar.setVisibility(View.GONE);
            }
        });

    }

}
