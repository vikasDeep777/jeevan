package com.appzdigital.amazingmarry.network;


import com.appzdigital.amazingmarry.model.CityModel.CityModel;
import com.appzdigital.amazingmarry.model.CountryModel.CountryModel;
import com.appzdigital.amazingmarry.model.EducationFieldModel.EducationFieldModel;
import com.appzdigital.amazingmarry.model.EducationModel.EducationModel;
import com.appzdigital.amazingmarry.model.ForgotPassswordModel.ForgotPassswordModel;
import com.appzdigital.amazingmarry.model.HeightModel.HeightModel;
import com.appzdigital.amazingmarry.model.LoginModel.LoginModel;
import com.appzdigital.amazingmarry.model.RegisterModel;
import com.appzdigital.amazingmarry.model.SpinnerModel.SpinnerModel;
import com.appzdigital.amazingmarry.model.StateModel.StateModel;
import com.appzdigital.amazingmarry.model.UserListModel.UserListModel;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface RestInterfaces {


    @Multipart
    @POST("amazing/user_register")
    Call<RegisterModel> registerUser(@Part("image\"; filename=\"myfile.jpg\" ") RequestBody file,
                                     @Part("apikey") RequestBody apikey,
                                     @Part("v_code") RequestBody v_code,
                                     @Part("deviceType") RequestBody deviceType,
                                     @Part("deviceID") RequestBody deviceID,
                                     @Part("device_token") RequestBody device_token,
                                     @Part("quick_blox_id") RequestBody quick_blox_id,
                                     @Part("latitude") RequestBody latitude,
                                     @Part("longitude") RequestBody longitude,
                                     @Part("permanent_address") RequestBody permanent_address,
                                     @Part("first_name") RequestBody first_name,
                                     @Part("last_name") RequestBody last_name,
                                     @Part("email") RequestBody email,
                                     @Part("password") RequestBody password,
                                     @Part("mobileNo") RequestBody mobileNo,
                                     @Part("gender") RequestBody gender,
                                     @Part("profile_for") RequestBody profile_for,
                                     @Part("dob") RequestBody dob,
                                     @Part("city") RequestBody city,
                                     @Part("state") RequestBody state,
                                     @Part("country") RequestBody country,
                                     @Part("education_category") RequestBody education_category,
                                     @Part("qualification") RequestBody qualification,
                                     @Part("hobbies") RequestBody hobbies,
                                     @Part("fav_actor") RequestBody fav_actor,
                                     @Part("fav_actress") RequestBody fav_actress,
                                     @Part("food_type") RequestBody food_type,
                                     @Part("partner_type") RequestBody partner_type,
                                     @Part("mother_tongue") RequestBody mother_tongue,
                                     @Part("marital_status") RequestBody marital_status,
                                     @Part("occupation_sector") RequestBody occupation_sector,
                                     @Part("occupation_type") RequestBody occupation_type,
                                     @Part("religion") RequestBody religion,
                                     @Part("height") RequestBody height,
                                     @Part("caste") RequestBody caste);


    @GET("amazing/profile_for_list?apikey=fbb36f24d9b3985aa86fa37fd51c29eb")
    Call<SpinnerModel> spinner_list();

    @GET("amazing/mother_tongue_list")
    Call<SpinnerModel> mother_tongue_list();

    @GET("amazing/religion_list?apikey=fbb36f24d9b3985aa86fa37fd51c29eb")
    Call<SpinnerModel> religion_list();

    @GET("amazing/occupation_sector_list?apikey=fbb36f24d9b3985aa86fa37fd51c29eb")
    Call<SpinnerModel> occupation();

    @GET("amazing/occupation_type_list?apikey=fbb36f24d9b3985aa86fa37fd51c29eb")
    Call<SpinnerModel> occupationType();

    @GET("amazing/food_list?apikey=fbb36f24d9b3985aa86fa37fd51c29eb")
    Call<SpinnerModel> food_type();

    @GET("amazing/maiterial_status_list?apikey=fbb36f24d9b3985aa86fa37fd51c29eb")
    Call<SpinnerModel> marital_status();

    @GET("amazing/country_list?apikey=fbb36f24d9b3985aa86fa37fd51c29eb")
    Call<CountryModel> countryList();

    @POST("amazing/state_list")
    Call<StateModel> stateList(@Body RequestBody body);


    @POST("amazing/city_list")
    Call<CityModel> cityList(@Body RequestBody body);

    @GET("amazing/education_level_list")
    Call<EducationModel> education();

    @GET("amazing/qualification_list?apikey=fbb36f24d9b3985aa86fa37fd51c29eb")
    Call<EducationFieldModel> educationField();

    @GET("amazing/height_list?apikey=fbb36f24d9b3985aa86fa37fd51c29eb")
    Call<HeightModel> height();



    @POST("amazing/login_user")
    Call<LoginModel> loginUser(@Body RequestBody body);

    @POST("amazing/passwordreset")
    Call<ForgotPassswordModel> forgotPassword(@Body RequestBody body);

    @POST("amazing/searchrecord")
    Call<UserListModel> allUserList(@Body RequestBody body);
}
