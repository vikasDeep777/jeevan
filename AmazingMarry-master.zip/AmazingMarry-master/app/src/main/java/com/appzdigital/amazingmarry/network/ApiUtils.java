package com.appzdigital.amazingmarry.network;



public class ApiUtils {

    private ApiUtils() {}
    private static final String BASE_URL="https://www.amazingmarry.com/index.php/api/";

    public static RestInterfaces getAPIService() {

        return RetrofitClient.getClient(BASE_URL).create(RestInterfaces.class);
    }
}
