package com.appzdigital.amazingmarry.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.activity.ForgotPasswordActivity;
import com.appzdigital.amazingmarry.activity.LoginActivity;
import com.appzdigital.amazingmarry.activity.PaymentActivity;
import com.appzdigital.amazingmarry.utils.AppUtils;
import com.appzdigital.amazingmarry.utils.PrefrenceManager;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

import app.quick_chat.ui.activity.DialogsActivity;


public class ChatFragment extends Fragment implements PaymentResultListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private PrefrenceManager prefrenceManager;

    private OnFragmentInteractionListener mListener;
    private View rootView;
    Button pay_btn;
    private String email,phone;


    public ChatFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static ChatFragment newInstance(String param1, String param2) {
        ChatFragment fragment = new ChatFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_chat, container, false);

        init();

        return rootView;
    }

    public void init(){

        //DialogsActivity.start(getContext());

        prefrenceManager=new PrefrenceManager(getContext());

        email=prefrenceManager.fetchEmail();
        phone=prefrenceManager.fetchMobileNo();


        pay_btn=rootView.findViewById(R.id.pay_btn);

        pay_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Intent intent = new Intent(getContext(), PaymentActivity.class);
                //startActivity(intent);
                startPayment(email,phone);

            }
        });
    }

    private void startPayment(String email,String phone) {
        Checkout checkout = new Checkout();
        checkout.setImage(R.drawable.logo);
        //final Activity activity = this;
        try {
            JSONObject options = new JSONObject();

            options.put("name", "Amazing Marry");
            options.put("description", "Premium membership fee");
            options.put("currency", "INR");
            options.put("amount", "4900");
            JSONObject preFill = new JSONObject();
            preFill.put("email", email);
            preFill.put("contact", phone);
            options.put("prefill", preFill);
            checkout.open(getActivity(), options);
        } catch(Exception e) {
            Log.e("", "Error in starting Razorpay Checkout", e);
        }
    }

    @Override
    public void onPaymentSuccess(String s) {
        AppUtils.customeToastGreenBottom("Payment successful",getContext());
    }

    @Override
    public void onPaymentError(int i, String s) {
        AppUtils.customeToastRedBottom("Payment failed",getContext());
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
