package com.appzdigital.amazingmarry.interfaces;

public interface ICallback3 {

    public void onItemClick(int pos);

}

