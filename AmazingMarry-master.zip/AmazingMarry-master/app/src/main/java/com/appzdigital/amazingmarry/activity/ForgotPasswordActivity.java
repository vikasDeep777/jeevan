package com.appzdigital.amazingmarry.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;

import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.databinding.ActivityForgotPasswordBinding;
import com.appzdigital.amazingmarry.model.ForgotPassswordModel.ForgotPassswordModel;
import com.appzdigital.amazingmarry.network.ApiUtils;
import com.appzdigital.amazingmarry.network.NetworkConnectionCheck;
import com.appzdigital.amazingmarry.network.RestInterfaces;
import com.appzdigital.amazingmarry.utils.AppConstant;
import com.appzdigital.amazingmarry.utils.AppUtils;

import org.json.JSONObject;

import java.util.Map;
import java.util.Objects;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPasswordActivity extends AppCompatActivity implements View.OnClickListener {


    private ActivityForgotPasswordBinding forgotPasswordBinding;
    private String email, deviceID;
    private ProgressDialog progressDialog;
    private NetworkConnectionCheck networkConnectionCheck;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        forgotPasswordBinding = DataBindingUtil.setContentView(this, R.layout.activity_forgot_password);

        init();
    }

    public void init() {

        progressDialog = new ProgressDialog(this);
        networkConnectionCheck = new NetworkConnectionCheck(getApplicationContext());
        deviceID = Settings.System.getString(ForgotPasswordActivity.this.getContentResolver(), Settings.Secure.ANDROID_ID);

        forgotPasswordBinding.resetBtn.setOnClickListener(this);
        forgotPasswordBinding.backLoginTxtView.setOnClickListener(this);
        TextWatcher();

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.back_login_txtView:
                Intent intent = new Intent(ForgotPasswordActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                break;

            case R.id.reset_btn:

                if (validationCheck()) {

                    if (networkConnectionCheck.isConnected()) {

                        ForgotPassword_request();
                        AppUtils.closeKeyboard(this, view);

                    }
                }

                break;

            default:
                break;
        }
    }

    private void ForgotPassword_request() {

        progressDialog.show();
        progressDialog.setMessage("Please Wait....");

        Map<String, Object> paramObject = new ArrayMap<>();
        paramObject.put("v_code", AppConstant.v_code);
        paramObject.put("apikey", AppConstant.apikey);
        paramObject.put("deviceType", AppConstant.deviceType);
        paramObject.put("deviceID", deviceID);
        paramObject.put("email", email);

        Log.d("", "ForgotPassword_request: " + paramObject.toString());

        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse(AppConstant.json_type), (new JSONObject(paramObject)).toString());
        Call<ForgotPassswordModel> forgotPassswordModelCall = iRestInterfaces.forgotPassword(body);
        Log.d("", "ForgotPassword_request: " + body);
        forgotPassswordModelCall.enqueue(new Callback<ForgotPassswordModel>() {
            @Override
            public void onResponse(Call<ForgotPassswordModel> call, Response<ForgotPassswordModel> response) {
                progressDialog.dismiss();


                if (response.body().getStatus().equals(true)) {

                    AppUtils.customeToastGreen(response.body().getMessage(), getApplicationContext());
                    forgotPasswordBinding.emailEdtTxt.getText().clear();

                } else {
                    AppUtils.customeToastRed(response.body().getMessage(), getApplicationContext());

                }
            }

            @Override
            public void onFailure(Call<ForgotPassswordModel> call, Throwable t) {

                progressDialog.dismiss();

                Log.d("", "onFailure: " + t);
            }
        });
    }

    public boolean validationCheck() {
        boolean check = false;

        email = Objects.requireNonNull(forgotPasswordBinding.emailEdtTxt.getText()).toString();

        if (check == false) {

            if (email.equals("")) {
                forgotPasswordBinding.emailEdtTxt.requestFocus();
                forgotPasswordBinding.emailEdtTxt.setError("Email should not be blank");
            } else if ((!AppUtils.isEmailValid(email))) {
                forgotPasswordBinding.emailEdtTxt.requestFocus();
                forgotPasswordBinding.emailEdtTxt.setError("Please enter correct email");
            } else {

                check = true;
            }
        }
        return check;
    }

    public void TextWatcher(){
        forgotPasswordBinding.emailEdtTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                email=forgotPasswordBinding.emailEdtTxt.getText().toString();

                if (email.length() == 0) {

                    forgotPasswordBinding.emailTxtInput.setBoxStrokeColor(ContextCompat.getColor(ForgotPasswordActivity.this, R.color.light_black));

                    forgotPasswordBinding.resetBtn.setAlpha(0.5f);
                    forgotPasswordBinding.resetBtn.setClickable(false);
                    forgotPasswordBinding.resetBtn.setEnabled(false);
                } else if (AppUtils.isEmailValid(email)) {

                    forgotPasswordBinding.emailTxtInput.setBoxStrokeColor(ContextCompat.getColor(ForgotPasswordActivity.this, R.color.toast_txtColour_green));

                    forgotPasswordBinding.resetBtn.setAlpha(1f);
                    forgotPasswordBinding.resetBtn.setClickable(true);
                    forgotPasswordBinding.resetBtn.setEnabled(true);

                } else {
                    forgotPasswordBinding.emailTxtInput.setBoxStrokeColor(ContextCompat.getColor(ForgotPasswordActivity.this, R.color.toast_txtColour_red));

                    forgotPasswordBinding.resetBtn.setAlpha(0.5f);
                    forgotPasswordBinding.resetBtn.setClickable(false);
                    forgotPasswordBinding.resetBtn.setEnabled(false);
                }

            }
        });


    }
}
