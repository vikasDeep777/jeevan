package com.appzdigital.amazingmarry.model;

public class PendingListModel {

    private String id;
    private String mobileNo;
    private String email;
    private String name;
    private String last_name;
    private String city;
    private String state;
    private String country;
    private String caste;
    private String religion;
    private String dob;
    private String image;
    private String height;
    private String marital_status;
    private String mother_tongue;
    private String occupation_sector;
    private String occupation_type;
    private String partner_type;
    private String food_type;
    private String education_category;
    private String qualification;
    private String fav_actor;
    private String fav_actress;
    private String distance;
    private String connection_info;

    public String getConnection_info() {
        return connection_info;
    }

    public void setConnection_info(String connection_info) {
        this.connection_info = connection_info;
    }


    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getMarital_status() {
        return marital_status;
    }

    public void setMarital_status(String marital_status) {
        this.marital_status = marital_status;
    }

    public String getMother_tongue() {
        return mother_tongue;
    }

    public void setMother_tongue(String mother_tongue) {
        this.mother_tongue = mother_tongue;
    }

    public String getOccupation_sector() {
        return occupation_sector;
    }

    public void setOccupation_sector(String occupation_sector) {
        this.occupation_sector = occupation_sector;
    }

    public String getOccupation_type() {
        return occupation_type;
    }

    public void setOccupation_type(String occupation_type) {
        this.occupation_type = occupation_type;
    }

    public String getPartner_type() {
        return partner_type;
    }

    public void setPartner_type(String partner_type) {
        this.partner_type = partner_type;
    }

    public String getFood_type() {
        return food_type;
    }

    public void setFood_type(String food_type) {
        this.food_type = food_type;
    }

    public String getEducation_category() {
        return education_category;
    }

    public void setEducation_category(String education_category) {
        this.education_category = education_category;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getFav_actor() {
        return fav_actor;
    }

    public void setFav_actor(String fav_actor) {
        this.fav_actor = fav_actor;
    }

    public String getFav_actress() {
        return fav_actress;
    }

    public void setFav_actress(String fav_actress) {
        this.fav_actress = fav_actress;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCaste() {
        return caste;
    }

    public void setCaste(String caste) {
        this.caste = caste;
    }

    public String getReligion() {
        return religion;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }



}
