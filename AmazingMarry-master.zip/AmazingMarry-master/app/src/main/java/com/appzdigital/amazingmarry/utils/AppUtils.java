package com.appzdigital.amazingmarry.utils;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.appzdigital.amazingmarry.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.content.Context.INPUT_METHOD_SERVICE;

public class AppUtils {
    public static final int FADE_DURATION = 1000 ;


    public static boolean isEmailValid(String email) {

        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
    public static boolean isValidMobile(String mobile)
    {
        return !TextUtils.isEmpty(mobile)&& Patterns.PHONE.matcher(mobile).matches();
    }

    public static boolean isValidPasswordLength(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            if (target.length() < 6 || target.length() > 15) {
                return false;
            } else {
                return true;
            }
        }

    }

    public static void closeKeyboard(AppCompatActivity appCompatActivity, View view) {
        InputMethodManager imm = (InputMethodManager) appCompatActivity.getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static void hideKeyboard(Activity activity){

        activity.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }



    public static String convertTo12Hour(String time) {
        try {
            final SimpleDateFormat sdf = new SimpleDateFormat("H:mm");
            final Date dateObj = sdf.parse(time);
            String convertedTime = new SimpleDateFormat("hh:mm a").format(dateObj);
            return convertedTime;
        } catch (final ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String convertTo24Hour(String Time) {
        DateFormat f1 = new SimpleDateFormat("h:mm aaa"); //11:00 pm
        Date d = null;
        try {
            d = f1.parse(Time);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        DateFormat f2 = new SimpleDateFormat("HH");
        String x = f2.format(d); // "23:00"

        return x;
    }

    public static String convertTo24Hour_min(String Time) {
        DateFormat f1 = new SimpleDateFormat("h:mm aaa"); //11:00 pm
        Date d = null;
        try {
            d = f1.parse(Time);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        DateFormat f2 = new SimpleDateFormat("mm");
        String x = f2.format(d); // "23:00"

        return x;
    }

    public static void setScaleAnimation(View view){
        ScaleAnimation anim = new ScaleAnimation(0.6f, 1.0f, 0.6f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        anim.setDuration(Long.valueOf(FADE_DURATION));
        view.startAnimation(anim);
    }



    public static void customeToastGreen(String msg,Context context)
    {
        LayoutInflater inflater = LayoutInflater.from(context);
        View child = inflater.inflate(R.layout.custome_toast, null);
        TextView text = (TextView) child.findViewById(R.id.toast_tv);
        CardView cardView = (CardView) child.findViewById(R.id.custom_toast_container);
        text.setText(msg);
        text.setTextColor(ContextCompat.getColor(context, R.color.toast_txtColour_green));
        cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.light_green));
        Toast toast = new Toast(context);
        toast.setGravity(Gravity.TOP, 0, 140);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(child);
        toast.show();
    }


    public static void customeToastRed(String msg,Context context)
    {
        LayoutInflater inflater = LayoutInflater.from(context);
        View child = inflater.inflate(R.layout.custome_toast, null);
        TextView text = (TextView) child.findViewById(R.id.toast_tv);
        CardView cardView = (CardView) child.findViewById(R.id.custom_toast_container);
        text.setText(msg);
        text.setTextColor(ContextCompat.getColor(context, R.color.toast_txtColour_red));
        cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.light_red));
        Toast toast = new Toast(context);
        toast.setGravity(Gravity.TOP, 0, 140);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(child);
        toast.show();
    }


    public static void customeToastGreenBottom(String msg,Context context)
    {
        LayoutInflater inflater = LayoutInflater.from(context);
        View child = inflater.inflate(R.layout.custome_toast, null);
        TextView text = (TextView) child.findViewById(R.id.toast_tv);
        CardView cardView = (CardView) child.findViewById(R.id.custom_toast_container);
        text.setText(msg);
        text.setTextColor(ContextCompat.getColor(context, R.color.toast_txtColour_green));
        cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.light_green));
        Toast toast = new Toast(context);
        toast.setGravity(Gravity.BOTTOM, 0, 140);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(child);
        toast.show();
    }


    public static void customeToastRedBottom(String msg,Context context)
    {
        LayoutInflater inflater = LayoutInflater.from(context);
        View child = inflater.inflate(R.layout.custome_toast, null);
        TextView text = (TextView) child.findViewById(R.id.toast_tv);
        CardView cardView = (CardView) child.findViewById(R.id.custom_toast_container);
        text.setText(msg);
        text.setTextColor(ContextCompat.getColor(context, R.color.toast_txtColour_red));
        cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.light_red));
        Toast toast = new Toast(context);
        toast.setGravity(Gravity.BOTTOM, 0, 140);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(child);
        toast.show();
    }


    public static int getAge(String dobString){
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
        try {
            date = sdf.parse(dobString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if(date == null) return 0;
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();
        dob.setTime(date);
        int year = dob.get(Calendar.YEAR);
        int month = dob.get(Calendar.MONTH);
        int day = dob.get(Calendar.DAY_OF_MONTH);
        dob.set(year, month+1, day);
        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)){
            age--;
        }
        return age;
    }

}
