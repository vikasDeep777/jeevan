package com.appzdigital.amazingmarry.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;

import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.databinding.ActivityLoginBinding;
import com.appzdigital.amazingmarry.model.LoginModel.LoginModel;
import com.appzdigital.amazingmarry.network.ApiUtils;
import com.appzdigital.amazingmarry.network.NetworkConnectionCheck;
import com.appzdigital.amazingmarry.network.RestInterfaces;
import com.appzdigital.amazingmarry.utils.AppConstant;
import com.appzdigital.amazingmarry.utils.AppUtils;
import com.appzdigital.amazingmarry.utils.PrefrenceManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.quickblox.core.QBEntityCallback;
import com.quickblox.core.exception.QBResponseException;
import com.quickblox.users.model.QBUser;

import org.json.JSONObject;

import java.util.Map;
import java.util.Objects;

import app.quick_chat.utils.SharedPrefsHelper;
import app.quick_chat.utils.chat.ChatHelper;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private ActivityLoginBinding loginBinding;
    private PrefrenceManager prefrenceManager;
    private NetworkConnectionCheck networkConnectionCheck;

    private ProgressDialog progressDialog;
    private String email, password, device_token, deviceID, msg;
    private SharedPreferences loginPreferences;
    private SharedPreferences.Editor loginPrefsEditor;
    private Boolean saveLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginBinding = DataBindingUtil.setContentView(this, R.layout.activity_login);

        init();
    }

    public void init() {

        loginBinding.forgotPasswordTxtView.setOnClickListener(this);
        loginBinding.rememberMeCheckBox.setOnClickListener(this);
        loginBinding.loginBtn.setOnClickListener(this);
        loginBinding.createNewBioLl.setOnClickListener(this);
        progressDialog = new ProgressDialog(this);
        networkConnectionCheck = new NetworkConnectionCheck(getApplicationContext());
        prefrenceManager = new PrefrenceManager(this);
        deviceID = Settings.System.getString(LoginActivity.this.getContentResolver(), Settings.Secure.ANDROID_ID);

        loginPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
        loginPrefsEditor = loginPreferences.edit();

        saveLogin = loginPreferences.getBoolean("saveLogin", false);
        if (saveLogin == true) {
            loginBinding.emailEdtTxt.setText(loginPreferences.getString("email", ""));
            loginBinding.passwordEdtTxt.setText(loginPreferences.getString("password", ""));

            loginBinding.emailEdtTxt.setSelection(loginBinding.emailEdtTxt.getText().length());
            loginBinding.passwordEdtTxt.setSelection(loginBinding.passwordEdtTxt.getText().length());

            loginBinding.rememberMeCheckBox.setChecked(true);
        }

        getDeviceToken();
        TextWatcher();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.forgot_password_txtView:
                Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
                startActivity(intent);
                break;
            case R.id.login_btn:

                if (validationCheck()) {

                    if (loginBinding.rememberMeCheckBox.isChecked()) {
                        loginPrefsEditor.putBoolean("saveLogin", true);
                        loginPrefsEditor.putString("email", email);
                        loginPrefsEditor.putString("password", password);
                        loginPrefsEditor.commit();
                    } else {
                        loginPrefsEditor.clear();
                        loginPrefsEditor.commit();
                    }

                    if (networkConnectionCheck.isConnected()) {

                        Login_request();
                        AppUtils.closeKeyboard(this, view);
                    }


                }

                break;
            case R.id.remember_me_check_box:

                break;

                case R.id.create_new_bio_ll:
                    Intent intent1 = new Intent(LoginActivity.this, RegisterActivity.class);
                    startActivity(intent1);
                break;
            default:
                break;
        }
    }

    private void Login_request() {

        progressDialog.show();
        progressDialog.setMessage("Please Wait....");

        Map<String, Object> paramObject = new ArrayMap<>();
        paramObject.put("v_code", AppConstant.v_code);
        paramObject.put("apikey", AppConstant.apikey);
        paramObject.put("deviceType", AppConstant.deviceType);
        paramObject.put("deviceID", deviceID);
        paramObject.put("device_token", device_token);
        paramObject.put("remember", "1");
        paramObject.put("email_or_moblie", email);
        paramObject.put("password", password);

        Log.d("", "Login_request: " + paramObject.toString());
        RestInterfaces iRestInterfaces = ApiUtils.getAPIService();
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse(AppConstant.json_type), (new JSONObject(paramObject)).toString());
        Call<LoginModel> loginModelCall = iRestInterfaces.loginUser(body);
        loginModelCall.enqueue(new Callback<LoginModel>() {
            @Override
            public void onResponse(Call<LoginModel> call, Response<LoginModel> response) {
                if (response.isSuccessful()) {

                    if (response.body().getStatus().equals(true)) {
                        msg = response.body().getMessage();
                        String user_id = String.valueOf(response.body().getResponse().getId());
                        String email = response.body().getResponse().getEmail();
                        String mobileNo = response.body().getResponse().getMobileNo();
                        String gender = response.body().getResponse().getGender();
                        String f_name = response.body().getResponse().getFirstname();
                        String l_name = response.body().getResponse().getLastname();
                        String latitude = response.body().getResponse().getLatitude();
                        String longitude = response.body().getResponse().getLongitude();
                        String current_address = response.body().getResponse().getPermanentAddress();
                        String quick_blox_id = response.body().getResponse().getQuickBloxId();
                        String photo = response.body().getResponse().getImage();
                        prefrenceManager.saveLoginResponseDetails(user_id, email, mobileNo, f_name,l_name, gender, latitude, longitude, current_address, quick_blox_id, photo);
                        ChatLogin(email);
                    } else {
                        AppUtils.customeToastRed(response.body().getMessage(), getApplicationContext());
                    }
                }
            }

            @Override
            public void onFailure(Call<LoginModel> call, Throwable t) {

                progressDialog.dismiss();
            }
        });
    }


    public boolean validationCheck() {
        boolean check = false;

        email = Objects.requireNonNull(loginBinding.emailEdtTxt.getText()).toString();
        password = Objects.requireNonNull(loginBinding.passwordEdtTxt.getText()).toString();

        if (check == false) {

            if (email.equals("")) {
                loginBinding.emailEdtTxt.requestFocus();
                loginBinding.emailEdtTxt.setError("Email or phone should not be blank");
            }  else if (password.equals("")) {
                loginBinding.passwordEdtTxt.requestFocus();
                loginBinding.passwordEdtTxt.setError("Password should not be blank");
            } else if (password.length() < 6 || password.length() > 15) {
                loginBinding.passwordEdtTxt.requestFocus();
                loginBinding.passwordEdtTxt.setError("Password should not be less than 6 digit");
            } else {

                check = true;
            }
        }
        return check;
    }

    private void getDeviceToken() {

        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w("", "getInstanceId failed", task.getException());
                            return;
                        }
                        // Get new Instance ID token
                        device_token = task.getResult().getToken();
                    }
                });
    }

    /*QuickBlox Login*/

    public void ChatLogin(String email) {

        final QBUser user = new QBUser(email, "12345678");
        ChatHelper.getInstance().login(user, new QBEntityCallback<Void>() {
            @Override
            public void onSuccess(Void result, Bundle bundle) {
                SharedPrefsHelper.getInstance().saveQbUser(user);
                Log.d("id==", String.valueOf(user.getId()));
                loginToChat(user, getApplicationContext());
            }

            @Override
            public void onError(QBResponseException e) {
            }
        });
    }

    private void loginToChat(final QBUser user, final Context context) {

        ChatHelper.getInstance().loginToChat(user, new QBEntityCallback<Void>() {
            @Override
            public void onSuccess(Void result, Bundle bundle) {
                //This method is calling to subscribe push notification
                progressDialog.dismiss();

                AppUtils.customeToastGreen(msg, getApplicationContext());
                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
                prefrenceManager.saveSessionLogin();
            }

            @Override
            public void onError(QBResponseException e) {
                Log.e("Chat login onError(): ", "" + e);

            }
        });
    }

    public void TextWatcher(){
        loginBinding.emailEdtTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                email=loginBinding.emailEdtTxt.getText().toString();

                if (email.length() == 0) {

                    loginBinding.emailTxtInput.setBoxStrokeColor(ContextCompat.getColor(LoginActivity.this, R.color.light_black));

                    loginBinding.loginBtn.setAlpha(0.5f);
                    loginBinding.loginBtn.setClickable(false);
                    loginBinding.loginBtn.setEnabled(false);
                }  else {
                    loginBinding.emailTxtInput.setBoxStrokeColor(ContextCompat.getColor(LoginActivity.this, R.color.toast_txtColour_green));

                    loginBinding.loginBtn.setAlpha(0.5f);
                    loginBinding.loginBtn.setClickable(false);
                    loginBinding.loginBtn.setEnabled(false);
                }

            }
        });


        loginBinding.passwordEdtTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                password=loginBinding.passwordEdtTxt.getText().toString();

                if (password.length() == 0) {

                    loginBinding.passwordTxtInput.setBoxStrokeColor(ContextCompat.getColor(LoginActivity.this, R.color.light_black));

                    loginBinding.loginBtn.setAlpha(0.5f);
                    loginBinding.loginBtn.setClickable(false);
                    loginBinding.loginBtn.setEnabled(false);
                } else if (password.length() < 6 || password.length() > 15) {

                    loginBinding.passwordTxtInput.setBoxStrokeColor(ContextCompat.getColor(LoginActivity.this, R.color.toast_txtColour_red));

                    loginBinding.loginBtn.setAlpha(0.5f);
                    loginBinding.loginBtn.setClickable(false);
                    loginBinding.loginBtn.setEnabled(false);

                } else {
                    loginBinding.passwordTxtInput.setBoxStrokeColor(ContextCompat.getColor(LoginActivity.this, R.color.toast_txtColour_green));

                    loginBinding.loginBtn.setAlpha(1f);
                    loginBinding.loginBtn.setClickable(true);
                    loginBinding.loginBtn.setEnabled(true);
                }

            }
        });

    }

}
