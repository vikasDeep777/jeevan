package com.appzdigital.amazingmarry.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.interfaces.ICallback;
import com.appzdigital.amazingmarry.model.SpinnerModel.Response;
import com.appzdigital.amazingmarry.utils.AppUtils;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SpinnerAdapter extends RecyclerView.Adapter<SpinnerAdapter.ViewUserViewHolder> {

    private ICallback iCallback;
    private List<Response> spinnerModels;
    private List<Response> filterlist;
    private Context context;


    public SpinnerAdapter(List spinnerModels, Context context, ICallback iCallback) {
        this.spinnerModels = spinnerModels;
        this.context = context;
        this.iCallback = iCallback;
        this.filterlist = new ArrayList<Response>();
        this.filterlist.addAll(spinnerModels);

    }

    @NonNull
    @Override
    public SpinnerAdapter.ViewUserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate the layout file
        View notification_list = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_spinner_item, parent, false);
        SpinnerAdapter.ViewUserViewHolder notificationlist = new SpinnerAdapter.ViewUserViewHolder(notification_list);
        AppUtils.setScaleAnimation(notification_list);
        return notificationlist;
    }

    @Override
    public void onBindViewHolder(@NonNull SpinnerAdapter.ViewUserViewHolder holder, final int position) {


        holder.item_txtView.setText(spinnerModels.get(position).getName());

        holder.card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iCallback.onItemClick(position);

            }
        });

    }

    @Override
    public int getItemCount() {
        return spinnerModels.size();
    }

    public class ViewUserViewHolder extends RecyclerView.ViewHolder {
        TextView item_txtView;
        CardView card_view;
        public ViewUserViewHolder(View view) {
            super(view);
            item_txtView = view.findViewById(R.id.item_txtView);
            card_view = view.findViewById(R.id.card_view);
        }
    }


    //ToDo Filter Class
    public void filter(CharSequence charText) {
        //charText = charText.toLowerCase(Locale.getDefault());
        spinnerModels.clear();
        if (charText.length() == 0) {
            spinnerModels.addAll(filterlist);
        } else {
            for (Response list : filterlist) {
                if (list.getName().toLowerCase(Locale.getDefault()).contains(charText)) {
                    spinnerModels.add(list);
                }
            }
        }
        notifyDataSetChanged();
    }
}



