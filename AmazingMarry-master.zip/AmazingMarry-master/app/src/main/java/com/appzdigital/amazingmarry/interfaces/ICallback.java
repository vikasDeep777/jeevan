package com.appzdigital.amazingmarry.interfaces;

public interface ICallback {

    public void onItemClick(int pos);

}

