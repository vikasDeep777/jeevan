package com.appzdigital.amazingmarry.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.activity.HomeActivity;
import com.appzdigital.amazingmarry.adapter.SearchUserAdapter;
import com.appzdigital.amazingmarry.interfaces.ICallback;
import com.appzdigital.amazingmarry.interfaces.ICallback2;
import com.appzdigital.amazingmarry.model.AllUserListModel;
import com.appzdigital.amazingmarry.network.AppGlobalsUrl;
import com.appzdigital.amazingmarry.network.NetworkConnectionCheck;
import com.appzdigital.amazingmarry.network.VolleySingleton;
import com.appzdigital.amazingmarry.utils.AppConstant;
import com.appzdigital.amazingmarry.utils.PrefrenceManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class ReqRejectFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private View rootView;
    private NetworkConnectionCheck networkConnectionCheck;
    private ProgressDialog progressDialog;
    private PrefrenceManager prefrenceManager;
    private TextView tvNoData;
    private SearchUserAdapter allUserListAdapter;
    private List<AllUserListModel> all_user_list ;
    private ProgressBar myprogressbar;
    private ICallback iCallback;
    private ICallback2 iCallback2;
    private RecyclerView recycler_view;

    private OnFragmentInteractionListener mListener;

    public ReqRejectFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static ReqRejectFragment newInstance(String param1, String param2) {
        ReqRejectFragment fragment = new ReqRejectFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_req_reject, container, false);

        init();

        return rootView;
    }

    private void init(){

        recycler_view = rootView.findViewById(R.id.recycler_view);
        myprogressbar = rootView.findViewById(R.id.p_bar);
        tvNoData = rootView.findViewById(R.id.tvNoData);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recycler_view.setLayoutManager(layoutManager);

        networkConnectionCheck = new NetworkConnectionCheck(getActivity());
        prefrenceManager = new PrefrenceManager(getActivity());

        all_user_list = new ArrayList<>();

        if (networkConnectionCheck.isConnected()){

            req_reject_list_NetworkCall();
        }

        iCallback=new ICallback() {
            @Override
            public void onItemClick(int pos) {

                Bundle bundle = new Bundle();
                bundle.putString("req_id", all_user_list.get(pos).getId());
                bundle.putString("photo", all_user_list.get(pos).getImage());
                bundle.putString("f_name", all_user_list.get(pos).getName());
                bundle.putString("l_name", all_user_list.get(pos).getLast_name());
                bundle.putString("dob", all_user_list.get(pos).getDob());
                bundle.putString("country", all_user_list.get(pos).getCountry());
                bundle.putString("city", all_user_list.get(pos).getCity());
                bundle.putString("phone", all_user_list.get(pos).getMobileNo());
                bundle.putString("email", all_user_list.get(pos).getEmail());
                bundle.putString("height", all_user_list.get(pos).getHeight());
                bundle.putString("marital_status", all_user_list.get(pos).getMarital_status());
                bundle.putString("food_type", all_user_list.get(pos).getFood_type());
                bundle.putString("religions", all_user_list.get(pos).getReligion());
                bundle.putString("mother_tongue", all_user_list.get(pos).getMother_tongue());
                bundle.putString("caste", all_user_list.get(pos).getCaste());
                bundle.putString("connection_status", all_user_list.get(pos).getConnection_info());
                bundle.putString("life_partner_like", all_user_list.get(pos).getPartner_type());
                bundle.putString("education", all_user_list.get(pos).getEducation_category()+" in "+all_user_list.get(pos).getQualification());
                bundle.putString("carrier", all_user_list.get(pos).getOccupation_sector()+"/"+all_user_list.get(pos).getOccupation_type());


                UserProfileDetailsFragment userProfileDetailsFragment = new UserProfileDetailsFragment();
                userProfileDetailsFragment.setArguments(bundle);
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame_container, userProfileDetailsFragment, "User Detail");
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        };
    }

    private void req_reject_list_NetworkCall() {
        myprogressbar.setVisibility(View.VISIBLE);
        HashMap<String, String> paramObject = new HashMap<String, String>();
        paramObject.put("v_code", AppConstant.v_code);
        paramObject.put("apikey", AppConstant.apikey);
        paramObject.put("connected_status", "3");
        paramObject.put("login_user_id", prefrenceManager.fetchUserId());

        final JSONObject jsonObject = new JSONObject(paramObject);
        Log.e("rejected_list--", "" + jsonObject);
        JsonObjectRequest req = new com.android.volley.toolbox.JsonObjectRequest(AppGlobalsUrl.connection_list, new JSONObject(paramObject), new com.android.volley.Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONObject jsonObject = new JSONObject(String.valueOf(response));
                    myprogressbar.setVisibility(View.GONE);
                    all_user_list.clear();
                    if (jsonObject.optString("status").equalsIgnoreCase("true")) {

                        JSONArray jsonArray1 = jsonObject.getJSONArray("response");
                        if (jsonArray1.length() > 0) {
                            for (int j = 0; j < jsonArray1.length(); j++) {
                                AllUserListModel listModel = new AllUserListModel();
                                JSONObject jsonObject1 = jsonArray1.getJSONObject(j);
                                String id = jsonObject1.getString("id");
                                String mobileNo = jsonObject1.getString("mobileNo");
                                String email = jsonObject1.getString("email");
                                String name = jsonObject1.getString("name");
                                String last_name = jsonObject1.getString("last_name");
                                String city = jsonObject1.getString("city");
                                String state = jsonObject1.getString("state");
                                String country = jsonObject1.getString("country");
                                String caste = jsonObject1.getString("caste");
                                String religion = jsonObject1.getString("religion");
                                String dob = jsonObject1.getString("dob");
                                String image = jsonObject1.getString("image");
                                String height = jsonObject1.getString("height");
                                String marital_status = jsonObject1.getString("marital_status");
                                String mother_tongue = jsonObject1.getString("mother_tongue");
                                String occupation_sector = jsonObject1.getString("occupation_sector");
                                String occupation_type = jsonObject1.getString("occupation_type");
                                String partner_type = jsonObject1.getString("partner_type");
                                String food_type = jsonObject1.getString("food_type");
                                String education_category = jsonObject1.getString("education_category");
                                String qualification = jsonObject1.getString("qualification");
                                String fav_actor = jsonObject1.getString("fav_actor");
                                String fav_actress = jsonObject1.getString("fav_actress");
                                String connection_info = jsonObject1.getString("connected_info");

                                listModel.setId(id);
                                listModel.setMobileNo(mobileNo);
                                listModel.setEmail(email);
                                listModel.setName(name);
                                listModel.setLast_name(last_name);
                                listModel.setCity(city);
                                listModel.setState(state);
                                listModel.setCountry(country);
                                listModel.setCaste(caste);
                                listModel.setReligion(religion);
                                listModel.setDob(dob);
                                listModel.setImage(image);
                                listModel.setHeight(height);
                                listModel.setMarital_status(marital_status);
                                listModel.setMother_tongue(mother_tongue);
                                listModel.setOccupation_sector(occupation_sector);
                                listModel.setOccupation_type(occupation_type);
                                listModel.setPartner_type(partner_type);
                                listModel.setFood_type(food_type);
                                listModel.setEducation_category(education_category);
                                listModel.setQualification(qualification);
                                listModel.setFav_actor(fav_actor);
                                listModel.setFav_actress(fav_actress);
                                listModel.setDistance("null");
                                listModel.setConnection_info(connection_info);

                                all_user_list.add(listModel);
                            }
                            allUserListAdapter = new SearchUserAdapter(all_user_list, getActivity(), iCallback,iCallback2);
                            recycler_view.setAdapter(allUserListAdapter);
                            allUserListAdapter.notifyDataSetChanged();
                            checkNoDataCase("No one rejected");
                        }
                    } else {
                        if (all_user_list.size()<1)
                            checkNoDataCase("No one rejected");
                        //Toast.makeText(getContext(), "" + jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), "" + e.getMessage(), Toast.LENGTH_LONG).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                myprogressbar.setVisibility(View.GONE);
                checkNoDataCase("Currently under maintenance, Please check after some time !");
            }
        }) {
            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }
        };
        VolleySingleton.getInstance(getContext()).addToRequestQueue(req);
    }

    private void checkNoDataCase(String msg){

        if(all_user_list.size()>0){
            recycler_view.setVisibility(View.VISIBLE);
            tvNoData.setVisibility(View.GONE);

        }else{
            recycler_view.setVisibility(View.GONE);
            tvNoData.setVisibility(View.VISIBLE);
            tvNoData.setText(msg);
        }

    }



    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
