package com.appzdigital.amazingmarry.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.databinding.FragmentUserProfileDetailsBinding;
import com.appzdigital.amazingmarry.network.AppGlobalsUrl;
import com.appzdigital.amazingmarry.network.VolleySingleton;
import com.appzdigital.amazingmarry.utils.AppConstant;
import com.appzdigital.amazingmarry.utils.AppUtils;
import com.appzdigital.amazingmarry.utils.PrefrenceManager;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;


public class UserProfileDetailsFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private View rootView;
    ProgressDialog progressDialog;
    PrefrenceManager prefrenceManager;
    private FragmentUserProfileDetailsBinding profileDetailsBinding;
    private String req_id,connection_status,photo,f_name,l_name,dob,country,city,phone,email,height,marital_status,food_type,religions,mother_tongue,caste,life_partner_like,education,carrier;


    private OnFragmentInteractionListener mListener;

    public UserProfileDetailsFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static UserProfileDetailsFragment newInstance(String param1, String param2) {
        UserProfileDetailsFragment fragment = new UserProfileDetailsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_user_profile_details, container, false);

        profileDetailsBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_user_profile_details, container, false);
        rootView = profileDetailsBinding.getRoot();

        init();

        return rootView;
    }

    private void init(){


        progressDialog=new ProgressDialog(getContext());
        prefrenceManager=new PrefrenceManager(getContext());

        if (getArguments() != null) {

            Bundle bundle = getArguments();
            photo = bundle.getString("photo");
            f_name = bundle.getString("f_name");
            l_name = bundle.getString("l_name");
            dob = bundle.getString("dob");
            country = bundle.getString("country");
            city = bundle.getString("city");
            phone = bundle.getString("phone");
            email = bundle.getString("email");
            height = bundle.getString("height");
            marital_status = bundle.getString("marital_status");
            food_type = bundle.getString("food_type");
            religions = bundle.getString("religions");
            mother_tongue = bundle.getString("mother_tongue");
            caste = bundle.getString("caste");
            education = bundle.getString("education");
            carrier = bundle.getString("carrier");
            life_partner_like = bundle.getString("life_partner_like");
            connection_status = bundle.getString("connection_status");
            req_id = bundle.getString("req_id");

        }

        profileDetailsBinding.nameTv.setText(f_name+" "+l_name+", "+getAge(dob));
        profileDetailsBinding.cityTv.setText(city+","+country);
        profileDetailsBinding.phoneNoTv.setText(phone);
        profileDetailsBinding.emailTv.setText(email);
        profileDetailsBinding.heightTv.setText(height);
        profileDetailsBinding.maritalStatusTv.setText(marital_status);
        profileDetailsBinding.locationTv.setText("Live in "+city+","+country);
        profileDetailsBinding.foodTypeTv.setText(food_type);
        profileDetailsBinding.religionTv.setText(religions+","+mother_tongue);
        profileDetailsBinding.castTv.setText(caste);
        profileDetailsBinding.lifePartnerTv.setText(life_partner_like);
        profileDetailsBinding.educationTv.setText(education);
        profileDetailsBinding.carrierTv.setText(carrier);

        if (photo.equalsIgnoreCase("")||photo.equalsIgnoreCase("null")){
            profileDetailsBinding.mainProfileIv.setImageResource(R.drawable.image);
        }else {
            Picasso.get().
                    load(AppGlobalsUrl.image_url+photo).
                    into(profileDetailsBinding.mainProfileIv);
        }

        if (connection_status.equalsIgnoreCase("0")){

            profileDetailsBinding.connectBtn.setText("connect");

        }else if (connection_status.equalsIgnoreCase("1")){

            profileDetailsBinding.connectBtn.setText("Requested");
            profileDetailsBinding.connectBtn.setBackgroundResource(R.drawable.btn_yellow_shape_round);


        }else if (connection_status.equalsIgnoreCase("2")){

            profileDetailsBinding.connectBtn.setText("Accepted");
            profileDetailsBinding.connectBtn.setBackgroundResource(R.drawable.btn_green_shape_round);


        }else if (connection_status.equalsIgnoreCase("3")){

            profileDetailsBinding.connectBtn.setText("Rejected");
            profileDetailsBinding.connectBtn.setBackgroundResource(R.drawable.btn_background_orange);

        }


        profileDetailsBinding.connectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (connection_status.equalsIgnoreCase("0")){

                    send_request_NetworkCall(req_id,"1");
                }

            }
        });
    }

    private int getAge(String dobString){

        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
        try {
            date = sdf.parse(dobString);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if(date == null) return 0;

        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.setTime(date);

        int year = dob.get(Calendar.YEAR);
        int month = dob.get(Calendar.MONTH);
        int day = dob.get(Calendar.DAY_OF_MONTH);

        dob.set(year, month+1, day);

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)){
            age--;
        }



        return age;
    }

    private void send_request_NetworkCall(String req_id,String status) {
        progressDialog.setMessage("Please wait....");
        progressDialog.show();
        HashMap<String, String> paramObject = new HashMap<String, String>();
        paramObject.put("v_code", AppConstant.v_code);
        paramObject.put("apikey", AppConstant.apikey);
        paramObject.put("connected_status", status);
        paramObject.put("requested_user_id", req_id);
        paramObject.put("login_user_id", prefrenceManager.fetchUserId());
        final JSONObject jsonObject = new JSONObject(paramObject);
        Log.e("send_req_call--", "" + jsonObject);
        JsonObjectRequest req = new com.android.volley.toolbox.JsonObjectRequest(AppGlobalsUrl.user_connection, new JSONObject(paramObject), new com.android.volley.Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONObject jsonObject = new JSONObject(String.valueOf(response));
                    progressDialog.dismiss();
                    if (jsonObject.optString("status").equalsIgnoreCase("true")) {

                        String message = jsonObject.getString("message");

                        AppUtils.customeToastGreen(message,getContext());

                        profileDetailsBinding.connectBtn.setText("Requested");
                        profileDetailsBinding.connectBtn.setBackgroundResource(R.drawable.btn_yellow_shape_round);

                    } else {

                        AppUtils.customeToastRed(jsonObject.getString("message"),getContext());

                        //Toast.makeText(getContext(), "" + jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), "" + e.getMessage(), Toast.LENGTH_LONG).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }
        };
        VolleySingleton.getInstance(getContext()).addToRequestQueue(req);
    }



    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
