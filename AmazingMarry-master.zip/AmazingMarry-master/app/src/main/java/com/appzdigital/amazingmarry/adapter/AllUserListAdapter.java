package com.appzdigital.amazingmarry.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.appzdigital.amazingmarry.R;
import com.appzdigital.amazingmarry.interfaces.ICallback;
import com.appzdigital.amazingmarry.interfaces.ICallback2;
import com.appzdigital.amazingmarry.model.AllUserListModel;
import com.appzdigital.amazingmarry.model.UserListModel.Response;
import com.appzdigital.amazingmarry.network.AppGlobalsUrl;
import com.appzdigital.amazingmarry.utils.AppUtils;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AllUserListAdapter extends RecyclerView.Adapter<AllUserListAdapter.ViewUserViewHolder> {

    private ICallback iCallback;
    private ICallback2 iCallback2;
    private List<AllUserListModel> userModel;
    private List<AllUserListModel> filterlist;
    private Context context;



    public AllUserListAdapter(List userModel, Context context, ICallback iCallback, ICallback2 iCallback2) {
        this.userModel = userModel;
        this.context = context;
        this.iCallback = iCallback;
        this.iCallback2 = iCallback2;
        this.filterlist = new ArrayList<AllUserListModel>();
        this.filterlist.addAll(userModel);

    }

    @NonNull
    @Override
    public AllUserListAdapter.ViewUserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate the layout file
        View notification_list = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_profile_item_list, parent, false);
        AllUserListAdapter.ViewUserViewHolder notificationlist = new AllUserListAdapter.ViewUserViewHolder(notification_list);
        AppUtils.setScaleAnimation(notification_list);
        return notificationlist;
    }

    @Override
    public void onBindViewHolder(@NonNull AllUserListAdapter.ViewUserViewHolder holder, final int position) {

        String f_name=userModel.get(position).getName();
        String l_name=userModel.get(position).getLast_name();
        String city=userModel.get(position).getCity();
        String country=userModel.get(position).getCountry();
        String caste=userModel.get(position).getCaste();
        String religion=userModel.get(position).getReligion();
        String dob=userModel.get(position).getDob();
        String image=userModel.get(position).getImage();
        String ds=userModel.get(position).getDistance();
        String connection_status=userModel.get(position).getConnection_info();

        if (connection_status.equalsIgnoreCase("0")){

            holder.connect_btn.setText("connect");

        }else if (connection_status.equalsIgnoreCase("1")){

            holder.connect_btn.setText("Requested");
          //  holder.connect_btn.setBackgroundResource(R.drawable.btn_yellow_shape_round);


        }else if (connection_status.equalsIgnoreCase("2")){

            holder.connect_btn.setText("Accepted");
          //  holder.connect_btn.setBackgroundResource(R.drawable.btn_green_shape_round);

        }else if (connection_status.equalsIgnoreCase("3")){

            holder.connect_btn.setText("Rejected");
           // holder.connect_btn.setBackgroundResource(R.drawable.btn_background_orange);

        }

        if (ds.equalsIgnoreCase("")||ds.equalsIgnoreCase("null")){
            holder.distance_tv.setText("");
        }else {
            double distance= Double.parseDouble(ds);
            double dis=convertMilesToKm(distance);
            holder.distance_tv.setText(String.format("%.2f", dis)+" km");
        }



        holder.name_tv.setText(f_name+" "+l_name+", "+AppUtils.getAge(dob));
        holder.city_tv.setText(city+", "+country);
        holder.cast_tv.setText(religion+", "+caste);

        if (image.equalsIgnoreCase("")||image.equalsIgnoreCase("null")){
            holder.main_profile_iv.setImageResource(R.drawable.image);
        }else {
            Picasso.get().
                    load(AppGlobalsUrl.image_url+image).
                    into(holder.main_profile_iv);
        }

        holder.card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iCallback.onItemClick(position);

            }
        });

        holder.connect_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                iCallback2.onItemClick(position);

            }
        });

    }

    @Override
    public int getItemCount() {
        return userModel.size();
    }

    public class ViewUserViewHolder extends RecyclerView.ViewHolder {
        TextView name_tv,city_tv,cast_tv,distance_tv;
        ImageView main_profile_iv;
        Button connect_btn;
        CardView card_view;
        public ViewUserViewHolder(View view) {
            super(view);
            main_profile_iv = view.findViewById(R.id.main_profile_iv);
            name_tv = view.findViewById(R.id.name_tv);
            city_tv = view.findViewById(R.id.city_tv);
            cast_tv = view.findViewById(R.id.cast_tv);
            connect_btn = view.findViewById(R.id.connect_btn);
            distance_tv = view.findViewById(R.id.distance_tv);
            card_view = view.findViewById(R.id.card_view);
        }
    }


    //ToDo Filter Class
    public void filter(CharSequence charText) {
        //charText = charText.toLowerCase(Locale.getDefault());
        userModel.clear();
        if (charText.length() == 0) {
            userModel.addAll(filterlist);
        } else {
            for (AllUserListModel list : filterlist) {
                if (list.getName().toLowerCase(Locale.getDefault()).contains(charText)) {
                    userModel.add(list);
                }
            }
        }
        notifyDataSetChanged();
    }

    public double convertMilesToKm(double miles){
        double km =  (miles * 1.60934);
        return km;
    }
}



