package com.appzdigital.amazingmarry.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefrenceManager {

    private static final String PREF_NAME = "Amazing Marry";
    private static final String LOG_IN_OUT = "session";

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context context;
    int PRIVATE_MODE = 0;

    public PrefrenceManager(Context context) {
        this.context = context;
        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();

    }


    public void saveRegisterResponse(String user_id, String email, String mobileNo, String f_name,String l_name, String gender, String latitude, String longitude, String current_address, String quickbloxid) {

        editor = pref.edit();
        editor.putString("user_id", user_id);
        editor.putString("email", email);
        editor.putString("mobileNo", mobileNo);
        editor.putString("f_name", f_name);
        editor.putString("l_name", l_name);
        editor.putString("gender", gender);
        editor.putString("latitude", latitude);
        editor.putString("longitude", longitude);
        editor.putString("current_address", current_address);
        editor.putString("quickbloxid", quickbloxid);

        editor.commit();

    }

    public void saveLoginResponseDetails(String user_id, String email, String mobileNo, String f_name,String l_name, String gender, String latitude, String longitude, String current_address, String quickbloxid, String photo) {

        editor = pref.edit();
        editor.putString("user_id", user_id);
        editor.putString("email", email);
        editor.putString("mobileNo", mobileNo);
        editor.putString("f_name", f_name);
        editor.putString("l_name", l_name);
        editor.putString("gender", gender);
        editor.putString("latitude", latitude);
        editor.putString("longitude", longitude);
        editor.putString("current_address", current_address);
        editor.putString("quickbloxid", quickbloxid);
        editor.putString("photo", photo);

        editor.commit();

    }


    /*User Details*/
    public String fetchUserId() {
        return pref.getString("user_id", "");
    }

    public String fetchEmail() {
        return pref.getString("email", "");
    }

    public String fetchMobileNo() {
        return pref.getString("mobileNo", "");
    }

    public String fetchF_name() {
        return pref.getString("f_name", "");
    } public String fetchL_name() {
        return pref.getString("l_name", "");
    }

    public String fetchGender() {
        return pref.getString("gender", "");
    }

    public String fetchLatitude() {
        return pref.getString("latitude", "");
    }

    public String fetchLongitude() {
        return pref.getString("longitude", "");
    }

    public String fetchCurrentAddress() {
        return pref.getString("current_address", "");
    }

    public String fetchQuickBloxId() {
        return pref.getString("quickbloxid", "");
    }

    public String fetchPhoto() {
        return pref.getString("photo", "");
    }


    public void saveLoginValidation(String val) {

        editor = pref.edit();
        editor.putString("val", val);

        editor.commit();
    }

    public String fetchLoginvalid() {
        return pref.getString("val", "");
    }


    public boolean validateSession() {
        if (pref.getBoolean(LOG_IN_OUT, false) == true) {
            return true;
        } else {
            return false;
        }
    }

    public void saveSessionLogin() {
        editor.putBoolean(LOG_IN_OUT, true);
        editor.commit();
    }

    public void isUserLogedOut() {
        editor = pref.edit();
        editor.putString("user_id", "");
        editor.putString("email", "");
        editor.putString("mobileNo", "");
        editor.putString("name", "");
        editor.putString("gender", "");
        editor.putString("latitude", "");
        editor.putString("longitude", "");
        editor.putString("current_address", "");
        editor.putString("quickbloxid", "");
        editor.putString("photo", "");
        editor.putString("val", "");
        editor.clear();
        editor.commit();

    }


}
