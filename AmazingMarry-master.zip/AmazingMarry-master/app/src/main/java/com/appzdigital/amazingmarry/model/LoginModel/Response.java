package com.appzdigital.amazingmarry.model.LoginModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("__ci_last_regenerate")
    @Expose
    private Integer ciLastRegenerate;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("mobileNo")
    @Expose
    private String mobileNo;
    @SerializedName("gender")
    @Expose
    private String gender;
    @SerializedName("firstname")
    @Expose
    private String firstname;
    @SerializedName("lastname")
    @Expose
    private String lastname;
    @SerializedName("device_token")
    @Expose
    private String deviceToken;
    @SerializedName("email_active_status")
    @Expose
    private String emailActiveStatus;
    @SerializedName("notification_status")
    @Expose
    private String notificationStatus;
    @SerializedName("quick_blox_id")
    @Expose
    private String quickBloxId;
    @SerializedName("latitude")
    @Expose
    private String latitude;
    @SerializedName("longitude")
    @Expose
    private String longitude;
    @SerializedName("created_at")
    @Expose
    private String createdAt;
    @SerializedName("profile_for")
    @Expose
    private String profileFor;
    @SerializedName("dob")
    @Expose
    private String dob;
    @SerializedName("permanent_address")
    @Expose
    private String permanentAddress;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("state")
    @Expose
    private String state;
    @SerializedName("country")
    @Expose
    private String country;
    @SerializedName("education_category")
    @Expose
    private String educationCategory;
    @SerializedName("qualification")
    @Expose
    private String qualification;
    @SerializedName("hobbies")
    @Expose
    private String hobbies;
    @SerializedName("fav_actor")
    @Expose
    private String favActor;
    @SerializedName("fav_actress")
    @Expose
    private String favActress;
    @SerializedName("food_type")
    @Expose
    private String foodType;
    @SerializedName("partner_type")
    @Expose
    private String partnerType;
    @SerializedName("mother_tongue")
    @Expose
    private String motherTongue;
    @SerializedName("occupation_sector")
    @Expose
    private String occupationSector;
    @SerializedName("occupation_type")
    @Expose
    private String occupationType;
    @SerializedName("religion")
    @Expose
    private String religion;
    @SerializedName("height")
    @Expose
    private String height;
    @SerializedName("height_m1")
    @Expose
    private Object heightM1;
    @SerializedName("height_m2")
    @Expose
    private Object heightM2;
    @SerializedName("caste")
    @Expose
    private String caste;
    @SerializedName("image")
    @Expose
    private String image;

    public Integer getCiLastRegenerate() {
        return ciLastRegenerate;
    }

    public void setCiLastRegenerate(Integer ciLastRegenerate) {
        this.ciLastRegenerate = ciLastRegenerate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }

    public String getEmailActiveStatus() {
        return emailActiveStatus;
    }

    public void setEmailActiveStatus(String emailActiveStatus) {
        this.emailActiveStatus = emailActiveStatus;
    }

    public String getNotificationStatus() {
        return notificationStatus;
    }

    public void setNotificationStatus(String notificationStatus) {
        this.notificationStatus = notificationStatus;
    }

    public String getQuickBloxId() {
        return quickBloxId;
    }

    public void setQuickBloxId(String quickBloxId) {
        this.quickBloxId = quickBloxId;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getProfileFor() {
        return profileFor;
    }

    public void setProfileFor(String profileFor) {
        this.profileFor = profileFor;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getEducationCategory() {
        return educationCategory;
    }

    public void setEducationCategory(String educationCategory) {
        this.educationCategory = educationCategory;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getHobbies() {
        return hobbies;
    }

    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }

    public String getFavActor() {
        return favActor;
    }

    public void setFavActor(String favActor) {
        this.favActor = favActor;
    }

    public String getFavActress() {
        return favActress;
    }

    public void setFavActress(String favActress) {
        this.favActress = favActress;
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public String getPartnerType() {
        return partnerType;
    }

    public void setPartnerType(String partnerType) {
        this.partnerType = partnerType;
    }

    public String getMotherTongue() {
        return motherTongue;
    }

    public void setMotherTongue(String motherTongue) {
        this.motherTongue = motherTongue;
    }

    public String getOccupationSector() {
        return occupationSector;
    }

    public void setOccupationSector(String occupationSector) {
        this.occupationSector = occupationSector;
    }

    public String getOccupationType() {
        return occupationType;
    }

    public void setOccupationType(String occupationType) {
        this.occupationType = occupationType;
    }

    public String getReligion() {
        return religion;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public Object getHeightM1() {
        return heightM1;
    }

    public void setHeightM1(Object heightM1) {
        this.heightM1 = heightM1;
    }

    public Object getHeightM2() {
        return heightM2;
    }

    public void setHeightM2(Object heightM2) {
        this.heightM2 = heightM2;
    }

    public String getCaste() {
        return caste;
    }

    public void setCaste(String caste) {
        this.caste = caste;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

}