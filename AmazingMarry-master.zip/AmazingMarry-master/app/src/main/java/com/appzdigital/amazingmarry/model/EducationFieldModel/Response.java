package com.appzdigital.amazingmarry.model.EducationFieldModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("qualification_in")
    @Expose
    private String qualificationIn;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQualificationIn() {
        return qualificationIn;
    }

    public void setQualificationIn(String qualificationIn) {
        this.qualificationIn = qualificationIn;
    }

}
