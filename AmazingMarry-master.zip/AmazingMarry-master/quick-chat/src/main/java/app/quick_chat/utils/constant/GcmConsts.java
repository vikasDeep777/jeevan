package app.quick_chat.utils.constant;

public interface GcmConsts {
    String EXTRA_GCM_MESSAGE = "message";
    String ACTION_NEW_GCM_EVENT = "new-push-event";
}
