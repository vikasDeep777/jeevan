package app.quick_chat.utils.constant;

public interface SchemeType {

    String SCHEME_CONTENT = "content";
    String SCHEME_CONTENT_GOOGLE = "content://com.google.android";
    String SCHEME_FILE = "file";

}
