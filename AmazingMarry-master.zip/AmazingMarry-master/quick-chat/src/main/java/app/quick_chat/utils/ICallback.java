package app.quick_chat.utils;

public interface ICallback {
    public void onSuccess(String data);
}
