package app.quick_chat.utils;

import android.content.ContentProvider;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {

}
