package app.quick_chat.utils.qb;

public interface PaginationHistoryListener {
    void downloadMore();
}
