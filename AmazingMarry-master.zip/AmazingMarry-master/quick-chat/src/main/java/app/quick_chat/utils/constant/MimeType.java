package app.quick_chat.utils.constant;

public interface MimeType {

    String IMAGE_MIME = "image/*";
    String STREAM_MIME = "application/octet-stream";
}
